// Import Firebase Messaging for TALKEVENT Application
importScripts(
    "https://www.gstatic.com/firebasejs/9.4.0/firebase-app-compat.js"
);
importScripts(
    "https://www.gstatic.com/firebasejs/9.4.0/firebase-messaging-compat.js"
);

// Initialize Firebase in the service worker using TALKEVENT-specific configuration.
firebase.initializeApp({
    apiKey: "YOUR_API_KEY",
    authDomain: "talkevent-app.firebaseapp.com",
    projectId: "talkevent-app",
    storageBucket: "talkevent-app.appspot.com",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID",
    measurementId: "YOUR_MEASUREMENT_ID",
});

// Retrieve an instance of Firebase Messaging for TALKEVENT.
const messaging = firebase.messaging();

messaging.onBackgroundMessage(function (payload) {
    try {
        console.log('TALKEVENT - onBackgroundMessage');
        // Customize notification for TALKEVENT here
        const { title, body } = payload.notification;
        console.log('TALKEVENT - title:', title, 'body:', body);
        const notificationOptions = {
            body,
            icon: "/talkevent-icon.png", // Use your TALKEVENT icon
        };

        // Show the TALKEVENT notification
        self.registration.showNotification(title, notificationOptions);
    } catch (error) {
        console.error('TALKEVENT - error:', error);
    }
});
