/**
 * Transform a string by adding a newline after every `spaces` spaces.
 *
 * @param {string} input - The input string to transform.
 * @param {number} spaces - The number of spaces after which to insert a newline. (Default: 3)
 * @returns {string} - The transformed string.
 */
const transformToNewline = (input, spaces = 3) => {
  let spaceCount = 0;
  let result = [];
  for (let i = 0; i < input.length; i++) {
    result.push(input[i]);
    if (input[i] === ' ') {
      spaceCount++;
      if (spaceCount % spaces === 0 && spaceCount !== 0) {
        result.push('\n');
      }
    }
  }
  return result.join('');
};

export { transformToNewline };
