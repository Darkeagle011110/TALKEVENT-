export function transformEventLocation(coordinates) {
  return coordinates.map(coordinate => {
    return { latitude: coordinate.lat, longitude: coordinate.lng };
  });
}
export function transformEventArea(coordinates) {
  const path = coordinates.map(point => {
    return { lng: point.longitude, lat: point.latitude };
  });

  // Ensure the path is closed by adding the first point at the end.
  if (path.length > 0) {
    path.push({ lng: path[0].lng, lat: path[0].lat });
  }

  return path;
}
