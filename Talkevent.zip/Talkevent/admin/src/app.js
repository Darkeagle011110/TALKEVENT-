import React, { useEffect, useState } from 'react';
import { getToken, onMessage } from 'firebase/messaging';
import Layout from './layouts/Layout'; // Replace with your application's layout
import { PrivateRoute } from './views/PrivateRoute';
import { HashRouter, Route, Switch, Redirect } from 'react-router-dom';
import * as Sentry from '@sentry/react';
import { isFirebaseSupported, initialize } from './firebase.js'; // Initialize Firebase for notifications
import { uploadToken } from './apollo';
import { gql, useApolloClient } from '@apollo/client';
import { VAPID_KEY } from './config/constants.js';

require('./i18n');

const UPLOAD_TOKEN = gql`
  ${uploadToken}
`;

const App = () => {
  const client = useApolloClient();
  const [user] = useState(localStorage.getItem('user-enatega'));
  const userType = localStorage.getItem('user-enatega')
    ? JSON.parse(localStorage.getItem('user-enatega')).userType
    : null;

  useEffect(() => {
    if (user) {
      const initializeFirebase = async () => {
        if (await isFirebaseSupported()) {
          const messaging = initialize();
          Notification.requestPermission()
            .then(() => {
              getToken(messaging, {
                vapidKey: VAPID_KEY,
              })
                .then((token) => {
                  localStorage.setItem('messaging-token', token);
                  client
                    .mutate({
                      mutation: UPLOAD_TOKEN,
                      variables: {
                        id: JSON.parse(user).userId,
                        pushToken: token,
                      },
                    })
                    .then(() => {
                      console.log('upload token success');
                    })
                    .catch((error) => {
                      console.log('upload token error', error);
                    });
                })
                .catch((err) => {
                  console.log('getToken error', err);
                });
            })
            .catch(console.log);

          onMessage(messaging, function (payload) {
            console.log(payload);
            // Customize notification here for event-related notifications
            const notificationTitle = 'New Event Update';
            const notificationOptions = {
              body: payload.data.eventName,
              icon: 'https://your-app.com/favicon.png',
            };
            const nt = new Notification(notificationTitle, notificationOptions);
            nt.onclick = function (event) {
              event.preventDefault();
              // Handle the notification click event (e.g., open the event details page)
              nt.close();
            };
          });
        }
      };
      initializeFirebase();
    }
  }, [user]);

  // Define your application's default route based on user type
  const route = userType
    ? userType === 'EVENT_ORGANIZER'
      ? '/event-management' // Redirect event organizers to event management
      : '/user-dashboard' // Redirect attendees to the user dashboard
    : '/auth/login'; // Redirect unauthenticated users to the login page

  return (
    <Sentry.ErrorBoundary>
      <HashRouter basename="/">
        <Switch>
          <PrivateRoute
            path="/event-management"
            component={(props) => <Layout {...props} />} // Use your event management layout
          />
          <PrivateRoute
            path="/user-dashboard"
            component={(props) => <Layout {...props} />} // Use your user dashboard layout
          />
          <Route path="/auth" component={(props) => <Layout {...props} />} /> {/* Use your authentication layout */}
          <Redirect from="/" to={route} />
        </Switch>
      </HashRouter>
    </Sentry.ErrorBoundary>
  );
};

export default Sentry.withProfiler(App);
