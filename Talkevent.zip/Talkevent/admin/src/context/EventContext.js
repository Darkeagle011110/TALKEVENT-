import React, { useContext, useState } from 'react';

export const EventContext = React.createContext();

export const EventProvider = (props) => {
  const [eventData, setEventData] = useState({
    title: '',
    description: '',
    category: '',
    location: '',
    date: '',
    time: '',
    price: 0,
    capacity: 0,
    image: null,
  });

  return (
    <EventContext.Provider value={{ eventData, setEventData }}>
      {props.children}
    </EventContext.Provider>
  );
};

export const useEventContext = () => useContext(EventContext);
