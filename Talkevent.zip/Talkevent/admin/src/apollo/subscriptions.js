export const subscribeNewEvent = `
  subscription SubscribeNewEvent {
    newEvent {
      _id
      title
      date
      location
      organizer
      attendees
    }
  }
`;

export const subscribeNewBooking = `
  subscription SubscribeNewBooking {
    newBooking {
      _id
      event
      user
      tickets
    }
  }
`;

export const subscribeUserActivity = `
  subscription SubscribeUserActivity {
    userActivity {
      _id
      username
      email
      events
    }
  }
`;

export const subscribeEventActivity = `
  subscription SubscribeEventActivity {
    eventActivity {
      _id
      title
      date
      location
      organizer
      attendees
    }
  }
`;

export const subscribeBookingActivity = `
  subscription SubscribeBookingActivity {
    bookingActivity {
      _id
      event
      user
      tickets
    }
  }
`;

export const subscribeReviewEvent = `
  subscription SubscribeReviewEvent($restaurant: String!) {
    reviewEvent(restaurant: $restaurant) {
      _id
      order {
        _id
        orderId
        items {
          title
        }
        user {
          _id
          name
          email
        }
      }
      restaurant {
        _id
        name
        image
      }
      rating
      description
      createdAt
    }
  }
`;

export const subscribeOrderStatus = `
  subscription SubscribeOrderStatus($id: String!) {
    orderStatus(id: $id) {
      _id
      orderStatus
      rider {
        _id
      }
    }
  }
`;

// Additional GraphQL subscriptions for TALKEVENT can be added here
