export const createEvent = `
  mutation CreateEvent($eventInput: EventInput!) {
    createEvent(eventInput: $eventInput) {
      _id
      title
      date
      location
      organizer
      attendees
    }
  }
`;

export const editEvent = `
  mutation EditEvent($eventInput: EventInput!) {
    editEvent(eventInput: $eventInput) {
      _id
      title
      date
      location
      organizer
      attendees
    }
  }
`;

export const deleteEvent = `
  mutation DeleteEvent($id: String!) {
    deleteEvent(id: $id) {
      _id
      title
    }
  }
`;

export const createBooking = `
  mutation CreateBooking($bookingInput: BookingInput!) {
    createBooking(bookingInput: $bookingInput) {
      _id
      event
      user
      tickets
    }
  }
`;

export const editBooking = `
  mutation EditBooking($bookingInput: BookingInput!) {
    editBooking(bookingInput: $bookingInput) {
      _id
      event
      user
      tickets
    }
  }
`;

export const deleteBooking = `
  mutation DeleteBooking($id: String!) {
    deleteBooking(id: $id) {
      _id
      event
    }
  }
`;

export const createUser = `
  mutation CreateUser($userInput: UserInput!) {
    createUser(userInput: $userInput) {
      _id
      username
      email
      events
    }
  }
`;

export const editUser = `
  mutation EditUser($userInput: UserInput!) {
    editUser(userInput: $userInput) {
      _id
      username
      email
      events
    }
  }
`;

export const deleteUser = `
  mutation DeleteUser($id: String!) {
    deleteUser(id: $id) {
      _id
      username
    }
  }
`;

// Additional GraphQL mutations for TALKEVENT can be added below
