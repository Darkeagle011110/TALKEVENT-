export const getEvents = `
  query GetEvents($page: Int) {
    allEvents(page: $page) {
      _id
      title
      date
      location
      organizer
      attendees
    }
  }
`;

export const getBookings = `
  query GetBookings($page: Int) {
    allBookings(page: $page) {
      _id
      event
      user
      tickets
    }
  }
`;

export const getUsers = `
  query GetUsers($page: Int) {
    allUsers(page: $page) {
      _id
      username
      email
      events
    }
  }
`;

export const getActiveUsers = `
  query GetActiveUsers {
    activeUsers {
      _id
      username
      email
      events
    }
  }
`;

export const getActiveEvents = `
  query GetActiveEvents {
    activeEvents {
      _id
      title
      date
      location
      organizer
      attendees
    }
  }
`;

export const getActiveBookings = `
  query GetActiveBookings {
    activeBookings {
      _id
      event
      user
      tickets
    }
  }
`;

export const getReviews = `
  query GetReviews($restaurant: String!) {
    restaurantReviews(restaurant: $restaurant) {
      _id
      order {
        _id
        orderId
        items {
          title
        }
        user {
          _id
          name
          email
        }
      }
      restaurant {
        _id
        name
        image
      }
      rating
      description
      createdAt
    }
  }
`;

// Additional GraphQL queries for TALKEVENT can be added here
