import React, { useRef, useEffect } from 'react';
import { Route, Switch } from 'react-router-dom';
import { Container } from '@mui/material';

// Import components and routes related to event booking
import EventNavbar from '../components/Navbars/EventNavbar';
import EventFooter from '../components/Footers/EventFooter';
import eventRoutes from '../eventRoutes'; // Define your event-related routes

function EventBooking(props) {
  var divRef = useRef(null);

  useEffect(() => {
    document.documentElement.scrollTop = 0;
    document.scrollingElement.scrollTop = 0;
    divRef.current.scrollTop = 0;
  }, []);

  const getRoutes = (routes) => {
    return routes.map((prop, key) => {
      if (prop.layout === '/event') {
        return (
          <Route
            path={prop.layout + prop.path}
            component={prop.component}
            key={key}
          />
        );
      } else {
        return null;
      }
    });
  };

  const getBrandText = (path) => {
    for (let i = 0; i < eventRoutes.length; i++) {
      if (
        props.location.pathname.indexOf(eventRoutes[i].layout + eventRoutes[i].path) !== -1
      ) {
        return eventRoutes[i].name;
      }
    }
    return 'Event Booking';
  };

  return (
    <>
      <div ref={divRef}>
        <EventNavbar
          {...props}
          brandText={getBrandText(props.location.pathname)}
        />
        <Switch>{getRoutes(eventRoutes)}</Switch>
        <Container fluid>
          <EventFooter />
        </Container>
      </div>
    </>
  );
}

export default EventBooking;
