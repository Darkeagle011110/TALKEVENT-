import * as React from 'react';
import {
  AppBar,
  Box,
  Drawer,
  IconButton,
  Toolbar,
  Typography,
  Link,
  SvgIcon,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import { useLocation } from 'react-router-dom';
import routes from '../../routes';
import useStyles from './styles';

const drawerWidth = 240;

function EventOrganizerSidebar(props) {
  const location = useLocation();
  const classes = useStyles();
  const { window } = props;
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  }

  const createLinks = (
    <Box className={classes.sidebarBox}>
      <Toolbar className={[classes.rowDisplay, classes.logo]}>
        <Typography variant="h2" className={[classes.headingText, classes.logoText]}>
          TALKEVENT
        </Typography>
      </Toolbar>
      <Box className={classes.sidebarList}>
        {routes.map((prop, key) => {
          return prop.appearInSidebar ? (
            <>
              {key === 0 ? (
                <Typography className={classes.headingText} variant="h3">
                  {prop.category}
                </Typography>
              ) : null}
              <Link
                className={[
                  classes.rowDisplay,
                  classes.sidebarLink,
                  location.pathname === `${prop.layout}${prop.path}` &&
                    classes.active,
                ]}
                href={'#' + prop.layout + prop.path}
                underline="none">
                <SvgIcon
                  component={prop.icon}
                  htmlColor="red"
                  fontSize="small"
                />
                <Typography
                  variant="h6"
                  className={[
                    classes.linkText,
                    location.pathname !== `${prop.layout}${prop.path}`
                      ? classes.blackText
                      : classes.whiteText,
                  ]}>
                  {prop.name}
                </Typography>
              </Link>
            </>
          ) : null;
        })}
      </Box>
    </Box>
  );

  const container =
    window !== undefined ? () => window().document.body : undefined;

  return (
    <>
      <AppBar
        position="fixed"
        sx={{
          width: `calc(100% - ${drawerWidth}px)`,
          ml: `${drawerWidth}px`,
          display: 'none',
        }}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ display: 'none' }}>
            <MenuIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
      <Box
        component="nav"
        sx={{ width: drawerWidth, flexShrink: 0 }}
        aria-label="mailbox folders">
        <Drawer
          container={container}
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: 'block',
            '& .MuiDrawer-paper': { boxSizing: 'border-box', width: '70%' },
          }}>
          {createLinks}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: 'block',
            '& .MuiDrawer-paper': {
              boxSizing: 'border-box',
              width: drawerWidth,
              background: 'linear-gradient(180deg, #90EA93 50%, transparent 50%)',
              borderRight: 'none',
            },
          }}
          open>
          {createLinks}
        </Drawer>
      </Box>
    </>
  );
}

export default EventOrganizerSidebar;
