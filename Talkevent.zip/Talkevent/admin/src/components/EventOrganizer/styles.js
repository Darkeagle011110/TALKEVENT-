import { makeStyles } from '@mui/styles';

const useStyles = makeStyles((theme) => ({
  flexRow: {
    display: 'flex',
    flexDirection: 'row',
  },
  container: {
    backgroundColor: theme.palette.background.paper,
    margin: '30px 0',
    borderRadius: 25,
    boxShadow: '0px 0px 23px rgba(0, 0, 0, 0.1)',
    textAlign: 'center',
    paddingBottom: 5,
  },
  heading: {
    backgroundColor: theme.palette.primary.main,
    width: '50%',
    padding: 10,
    borderRadius: '20px 20px 0 0',
    textAlign: 'center',
  },
  text: {
    color: theme.palette.common.black,
    fontWeight: 'bold',
  },
  form: {
    margin: 25,
    alignItems: 'center',
  },
  image: {
    width: 120,
    height: 120,
    borderRadius: '50%',
  },
  file: {
    display: 'none',
  },
  fileUpload: {
    marginTop: 10,
    backgroundColor: theme.palette.primary.main,
    display: 'inline-block',
    padding: '3px 6px',
    cursor: 'pointer',
    color: theme.palette.common.white,
    borderRadius: 10,
    fontSize: 12,
  },
}));

export default useStyles;
