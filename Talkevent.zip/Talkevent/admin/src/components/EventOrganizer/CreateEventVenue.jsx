import React, { useState, useRef } from 'react';
import { validateFunc } from '../../constraints/constraints';
import { withTranslation } from 'react-i18next';
import { useMutation, gql } from '@apollo/client';
import { createEventVenue, eventVenuesByOwner } from '../../apollo';
import { CLOUDINARY_UPLOAD_URL, CLOUDINARY_EVENTS } from '../../config/constants';
import { Box, Alert, Typography, Button, Input, Switch } from '@mui/material';
import useStyles from './styles';
import useGlobalStyles from '../../utils/globalStyles';

const CREATE_EVENT_VENUE = gql`
  ${createEventVenue}
`;

const EVENT_VENUES_BY_OWNER = gql`
  ${eventVenuesByOwner}
`;

const CreateEventVenue = (props) => {
  const owner = props.owner;

  const [imgUrl, setImgUrl] = useState('');
  const [nameError, setNameError] = useState(null);
  const [usernameError, setUsernameError] = useState(null);
  const [passwordError, setPasswordError] = useState(null);
  const [addressError, setAddressError] = useState(null);
  const [capacityError, setCapacityError] = useState(null);
  const [descriptionError, setDescriptionError] = useState(null);
  const [errors, setErrors] = useState('');
  const [success, setSuccess] = useState('');

  const onCompleted = (data) => {
    setNameError(null);
    setAddressError(null);
    setUsernameError(null);
    setPasswordError(null);
    setCapacityError(null);
    setDescriptionError(null);
    setErrors('');
    setSuccess('Event Venue added');
    clearFormValues();
    setTimeout(hideAlert, 5000);
  };

  const onError = ({ graphQLErrors, networkError }) => {
    console.log('graphQLErrors', graphQLErrors);
    console.log('networkErrors', networkError);
    setNameError(null);
    setAddressError(null);
    setUsernameError(null);
    setPasswordError(null);
    setCapacityError(null);
    setDescriptionError(null);
    setSuccess('');
    if (graphQLErrors) {
      setErrors('Server error');
    }
    if (networkError) {
      setErrors('Network error');
    }
    setTimeout(hideAlert, 5000);
  };

  const hideAlert = () => {
    setErrors('');
    setSuccess('');
  };

  const [mutate, { loading }] = useMutation(CREATE_EVENT_VENUE, {
    onError,
    onCompleted,
    update,
  });

  const formRef = useRef(null);

  const selectImage = (event, state) => {
    const result = filterImage(event);
    if (result) imageToBase64(result);
  };

  const filterImage = (event) => {
    let images = [];
    for (let i = 0; i < event.target.files.length; i++) {
      images[i] = event.target.files.item(i);
    }
    images = images.filter((image) => image.name.match(/\.(jpg|jpeg|png|gif)$/));
    return images.length ? images[0] : undefined;
  };

  const imageToBase64 = (imgUrl) => {
    const fileReader = new FileReader();
    fileReader.onloadend = () => {
      setImgUrl(fileReader.result);
    };
    fileReader.readAsDataURL(imgUrl);
  };

  const uploadImageToCloudinary = async () => {
    if (imgUrl === '') return imgUrl;

    const apiUrl = CLOUDINARY_UPLOAD_URL;
    const data = {
      file: imgUrl,
      upload_preset: CLOUDINARY_EVENTS,
    };
    try {
      const result = await fetch(apiUrl, {
        body: JSON.stringify(data),
        headers: {
          'content-type': 'application/json',
        },
        method: 'POST',
      });
      const imageData = await result.json();
      return imageData.secure_url;
    } catch (e) {
      console.log(e);
    }
  };

  const onSubmitValidation = (data) => {
    const form = formRef.current;
    const name = form.name.value;
    const address = form.address.value;
    const username = form.username.value;
    const password = form.password.value;
    const capacity = form.capacity.value;
    const description = form.description.value;

    const nameError = !validateFunc({ name }, 'name');
    const addressError = !validateFunc({ address }, 'address');
    const usernameError = !validateFunc({ name: username }, 'name');
    const passwordError = !validateFunc({ password }, 'password');
    const capacityError = !validateFunc({ capacity }, 'capacity');
    const descriptionError = !validateFunc({ description }, 'description');

    setNameError(nameError);
    setAddressError(addressError);
    setUsernameError(usernameError);
    setPasswordError(passwordError);
    setCapacityError(capacityError);
    setDescriptionError(descriptionError);

    if (
      !(
        nameError &&
        addressError &&
        usernameError &&
        passwordError &&
        capacityError &&
        descriptionError
      )
    ) {
      setErrors('Fields Required');
    }

    return (
      nameError &&
      addressError &&
      usernameError &&
      passwordError &&
      capacityError &&
      descriptionError
    );
  };

  function update(cache, { data: { createEventVenue } }) {
    const { eventVenuesByOwner } = cache.readQuery({
      query: EVENT_VENUES_BY_OWNER,
      variables: { id: owner },
    });
    cache.writeQuery({
      query: EVENT_VENUES_BY_OWNER,
      variables: { id: owner },
      data: {
        eventVenuesByOwner: {
          ...eventVenuesByOwner,
          eventVenues: [...eventVenuesByOwner.eventVenues, createEventVenue],
        },
      },
    });
  }

  const clearFormValues = () => {
    const form = formRef.current;
    form.name.value = '';
    form.address.value = '';
    form.username.value = '';
    form.password.value = '';
    form.capacity.value = '';
    form.description.value = '';
    setImgUrl('');
  };

  const classes = useStyles();
  const globalClasses = useGlobalStyles();

  return (
    <Box container className={classes.container}>
      <Box style={{ alignItems: 'start' }} className={classes.flexRow}>
        <Box item className={classes.heading}>
          <Typography variant="h6" className={classes.text}>
            Add Event Venue
          </Typography>
        </Box>
        <Box ml={30} mt={1}>
          <label>Available</label>
          <Switch defaultChecked style={{ color: 'black' }} />
        </Box>
      </Box>

      <Box className={classes.form}>
        <form ref={formRef}>
          <Box className={globalClasses.flexRow}>
            <Input
              name="username"
              id="input-type-username"
              placeholder="Venue's username"
              type="text"
              defaultValue={''}
              disableUnderline
              className={[
                globalClasses.input,
                usernameError === false
                  ? globalClasses.inputError
                  : usernameError === true
                  ? globalClasses.inputSuccess
                  : ''
              ]}
            />
            <Input
              name="password"
              id="input-type-password"
              placeholder="Venue's password"
              type="text"
              defaultValue={''}
              disableUnderline
              className={[
                globalClasses.input,
                passwordError === false
                  ? globalClasses.inputError
                  : passwordError === true
                  ? globalClasses.inputSuccess
                  : ''
              ]}
            />
          </Box>
          <Box className={globalClasses.flexRow}>
            <Input
              name="name"
              id="input-type-name"
              placeholder="Event Venue's name"
              type="text"
              defaultValue={''}
              disableUnderline
              className={[
                globalClasses.input,
                nameError === false
                  ? globalClasses.inputError
                  : nameError === true
                  ? globalClasses.inputSuccess
                  : ''
              ]}
            />
            <Input
              name="address"
              id="input-type-address"
              placeholder="Venue's address"
              type="text"
              defaultValue={''}
              disableUnderline
              className={[
                globalClasses.input,
                addressError === false
                  ? globalClasses.inputError
                  : addressError === true
                  ? globalClasses.inputSuccess
                  : ''
              ]}
            />
          </Box>
          <Box className={globalClasses.flexRow}>
            <Input
              name="capacity"
              id="input-type-capacity"
              placeholder="Venue's capacity"
              type="number"
              disableUnderline
              className={[
                globalClasses.input,
                capacityError === false
                  ? globalClasses.inputError
                  : capacityError === true
                  ? globalClasses.inputSuccess
                  : ''
              ]}
            />
          </Box>
          <Box className={globalClasses.flexRow}>
            <Input
              name="description"
              id="input-type-description"
              placeholder="Venue's description"
              type="text"
              defaultValue={''}
              disableUnderline
              className={[
                globalClasses.input,
                descriptionError === false
                  ? globalClasses.inputError
                  : descriptionError === true
                  ? globalClasses.inputSuccess
                  : ''
              ]}
            />
          </Box>
          <Box mt={3} style={{ alignItems: 'center' }} className={globalClasses.flex}>
            <img
              className={classes.image}
              alt="..."
              src={
                imgUrl ||
                'https://www.lifcobooks.com/wp-content/themes/shopchild/images/placeholder_book.png'
              }
            />
            <label htmlFor="file-upload" className={classes.fileUpload}>
              Upload an image
            </label>
            <input
              className={classes.file}
              id="file-upload"
              type="file"
              onChange={(event) => {
                selectImage(event, 'image_url');
              }}
            />
          </Box>
          <Box>
            <Button
              className={globalClasses.button}
              disabled={loading}
              onClick={async (e) => {
                e.preventDefault();
                if (onSubmitValidation()) {
                  const imgUpload = await uploadImageToCloudinary();
                  const form = formRef.current;
                  const name = form.name.value;
                  const address = form.address.value;
                  const capacity = form.capacity.value;
                  const username = form.username.value;
                  const password = form.password.value;
                  const description = form.description.value;

                  mutate({
                    variables: {
                      owner,
                      eventVenue: {
                        name,
                        address,
                        image:
                          imgUpload ||
                          'https://www.lifcobooks.com/wp-content/themes/shopchild/images/placeholder_book.png',
                        capacity: Number(capacity),
                        username,
                        password,
                        description
                      }
                    }
                  });
                }
              }}>
              SAVE
            </Button>
          </Box>
        </form>
        <Box mt={2}>
          {success && (
            <Alert
              className={globalClasses.alertSuccess}
              variant="filled"
              severity="success">
              {success}
            </Alert>
          )}
          {errors && (
            <Alert
              className={globalClasses.alertError}
              variant="filled"
              severity="error">
              {errors}
            </Alert>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default withTranslation()(CreateEventVenue);
