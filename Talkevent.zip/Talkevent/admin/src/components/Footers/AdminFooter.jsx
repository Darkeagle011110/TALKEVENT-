import * as React from 'react';
import { Box, Link, BottomNavigation, Typography } from '@mui/material';
import useStyles from './styles';

export default function EventFooter(props) {
  const [value, setValue] = React.useState(0);
  const classes = useStyles();

  return (
    <Box
      sx={{
        background: 'linear-gradient(237.49deg, #EEF4FA 0.63%, #DEE6ED 85.49%)',
      }}
      className={classes.footer}>
      <BottomNavigation
        sx={{
          background: 'linear-gradient(237.49deg, #EEF4FA 0.63%, #DEE6ED 85.49%)',
        }}
        showLabels
        value={value}
        onChange={(event, newValue) => {
          setValue(newValue);
        }}>
        <Typography className={classes.text}>�2023</Typography>

        <Link
          className={classes.link}
          href="https://talkevent.example.com/"
          target="_blank"
          underline="none">
          TALKEVENT
        </Link>
        <Link
          className={classes.link}
          href="https://talkevent.example.com/about"
          target="_blank"
          underline="none">
          About Us
        </Link>
        <Link
          className={classes.link}
          href="https://talkevent.example.com/blog"
          target="_blank"
          underline="none">
          Blog
        </Link>
      </BottomNavigation>
    </Box>
  );
}
