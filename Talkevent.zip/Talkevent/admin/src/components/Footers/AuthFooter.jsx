import * as React from 'react';
import { Box, Link, BottomNavigation, Typography } from '@mui/material';
import useStyles from './styles';

export default function AuthFooter(props) {
  const classes = useStyles();

  return (
    <Box className={classes.footer} sx={{ bgcolor: 'transparent' }}>
      <BottomNavigation sx={{ bgcolor: 'transparent' }} showLabels>
        <Typography className={classes.text}>�2023</Typography>

        <Link
          className={classes.link}
          href="https://talkevent.example.com/"
          target="_blank"
          underline="none">
          TALKEVENT
        </Link>
        <Link
          className={classes.link}
          href="https://talkevent.example.com/about"
          target="_blank"
          underline="none">
          About Us
        </Link>
        <Link
          className={classes.link}
          href="https://talkevent.example.com/blog"
          target="_blank"
          underline="none">
          Blog
        </Link>
      </BottomNavigation>
    </Box>
  );
}
