import React, { useState } from 'react';
import { useMutation, gql } from '@apollo/client';
import { withTranslation } from 'react-i18next';
import { Box, Typography, Input, Button, Alert } from '@mui/material';

// Define your GraphQL mutations (CREATE_CATEGORY and EDIT_CATEGORY) here

function Category(props) {
  const mutation = props.category ? EDIT_CATEGORY : CREATE_CATEGORY;
  const [mainError, mainErrorSetter] = useState('');
  const [success, successSetter] = useState('');
  const [category, setCategory] = useState(props.category ? props.category.title : '');
  const eventId = localStorage.getItem('eventId'); // Replace with your application's event identifier

  const onCompleted = data => {
    const message = props.category
      ? 'Category updated successfully'
      : 'Category added successfully';
    successSetter(message);
    mainErrorSetter('');
    setCategory('');
    setTimeout(hideAlert, 5000);
  };

  const onError = error => {
    const message = `Action failed. Please try again: ${error}`;
    successSetter('');
    mainErrorSetter(message);
    setTimeout(hideAlert, 5000);
  };

  const [mutate, { loading }] = useMutation(mutation, { onError, onCompleted });

  const hideAlert = () => {
    mainErrorSetter('');
    successSetter('');
  };

  const { t } = props;

  return (
    <Box container>
      <Box className={props.category ? 'your-class-for-edit' : 'your-class-for-add'}>
        <Typography variant="h6" className="your-text-class">
          {props.category ? t('Edit Category') : t('Add Category')}
        </Typography>
      </Box>
      <Box className="your-form-class">
        <form>
          <Box>
            <Input
              id="input-category"
              name="input-category"
              placeholder="Category (e.g., Wedding, Birthday)"
              type="text"
              defaultValue={category}
              onChange={e => {
                setCategory(e.target.value);
              }}
              disableUnderline
              className="your-input-class"
            />
          </Box>
          <Box>
            <Button
              className="your-button-class"
              disabled={loading}
              onClick={async e => {
                e.preventDefault();
                if (!loading) {
                  mutate({
                    variables: {
                      category: {
                        _id: props.category ? props.category._id : '',
                        title: category,
                        event: eventId,
                      },
                    },
                  });
                }
              }}
            >
              SAVE
            </Button>
          </Box>
          <Box mt={2}>
            {success && (
              <Alert variant="filled" severity="success">
                {success}
              </Alert>
            )}
            {mainError && (
              <Alert variant="filled" severity="error">
                {mainError}
              </Alert>
            )}
          </Box>
        </form>
      </Box>
    </Box>
  );
}

export default withTranslation()(Category);
