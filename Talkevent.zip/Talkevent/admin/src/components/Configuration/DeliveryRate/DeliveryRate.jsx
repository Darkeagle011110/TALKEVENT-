import React, { useState } from 'react';
import { withTranslation } from 'react-i18next';
import { useMutation, gql } from '@apollo/client';
import { validateFunc } from '../../../constraints/constraints';
import { saveServiceChargeConfiguration } from '../../../apollo';
import { Box, Typography, Input, Button } from '@mui/material';
import useStyles from '../styles';
import useGlobalStyles from '../../../utils/globalStyles';

const SAVE_SERVICE_CHARGE_CONFIGURATION = gql`
  ${saveServiceChargeConfiguration}
`;

function ServiceCharge(props) {
  const [serviceCharge, setServiceCharge] = useState(props.serviceCharge || 0);
  const [serviceChargeError, setServiceChargeError] = useState(null);
  const [mutate, { loading }] = useMutation(SAVE_SERVICE_CHARGE_CONFIGURATION);

  const validateInput = () => {
    const serviceChargeErrors = !validateFunc(
      { serviceCharge: serviceCharge },
      'serviceCharge'
    );

    setServiceChargeError(serviceChargeErrors);
    return serviceChargeErrors;
  };

  const classes = useStyles();
  const globalClasses = useGlobalStyles();

  return (
    <Box container className={classes.container}>
      <Box className={classes.flexRow}>
        <Box item className={classes.heading}>
          <Typography variant="h6" className={classes.text}>
            Service Charge
          </Typography>
        </Box>
      </Box>

      <Box className={classes.form}>
        <form>
          <Box className={globalClasses.flexRow}>
            <Input
              id="input-service-charge"
              name="input-service-charge"
              placeholder="Service charge"
              type="text"
              defaultValue={serviceCharge}
              onChange={(e) => {
                setServiceCharge(e.target.value);
              }}
              disableUnderline
              className={[
                globalClasses.input,
                serviceChargeError === false
                  ? globalClasses.inputError
                  : serviceChargeError === true
                  ? globalClasses.inputSuccess
                  : '',
              ]}
            />
          </Box>
          <Box>
            <Button
              className={globalClasses.button}
              disabled={loading}
              onClick={(e) => {
                e.preventDefault();
                if (validateInput()) {
                  mutate({
                    variables: {
                      serviceCharge: Number(serviceCharge),
                    },
                  });
                }
              }}
            >
              SAVE
            </Button>
          </Box>
        </form>
      </Box>
    </Box>
  );
}

export default withTranslation()(ServiceCharge);
