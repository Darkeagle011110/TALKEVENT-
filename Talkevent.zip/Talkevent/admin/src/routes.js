import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

// Import your components and views
import Home from './views/Home';
import About from './views/About';
import Contact from './views/Contact';
import AdminDashboard from './views/AdminDashboard';
import VendorDashboard from './views/VendorDashboard';

// Import your custom icons or Material-UI icons
import { HomeIcon, AboutIcon, ContactIcon, DashboardIcon, VendorIcon } from './your-icons';

const routes = [
  {
    path: '/',
    name: 'Home',
    icon: HomeIcon,
    component: Home,
    layout: '/app',
  },
  {
    path: '/about',
    name: 'About',
    icon: AboutIcon,
    component: About,
    layout: '/app',
  },
  {
    path: '/contact',
    name: 'Contact',
    icon: ContactIcon,
    component: Contact,
    layout: '/app',
  },
  {
    path: '/admin/dashboard',
    name: 'Admin Dashboard',
    icon: DashboardIcon,
    component: AdminDashboard,
    layout: '/admin',
  },
  {
    path: '/vendor/dashboard',
    name: 'Vendor Dashboard',
    icon: VendorIcon,
    component: VendorDashboard,
    layout: '/vendor',
  },
];

function App() {
  return (
    <Router>
      <Switch>
        {routes.map((route, index) => (
          <Route
            key={index}
            path={route.layout + route.path}
            exact
            component={route.component}
          />
        ))}
      </Switch>
    </Router>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));
