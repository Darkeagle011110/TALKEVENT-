import React, { useState } from 'react'
import EventCard from '../components/Event/Card'
import { Link } from 'react-router-dom'
import { useQuery, gql } from '@apollo/client'
import { eventsByOwner } from '../apollo'
import CreateEvent from '../components/Event/CreateEvent'
import { Box, Button, Modal, Container, Grid } from '@mui/material'
import AddIcon from '@mui/icons-material/Add'
import useGlobalStyles from '../utils/globalStyles'

const EVENTS_BY_OWNER = gql`
  ${eventsByOwner}
`

const Event = props => {
  const [owner, setOwner] = useState()
  const [isModalVisible, setIsModalVisible] = useState(false)
  const organizerId = localStorage.getItem('organizerId')
  const toggleModal = () => {
    setIsModalVisible(prevState => !prevState)
  }
  const loggedInUser = localStorage.getItem('user-talkevent')
  const { userType } = loggedInUser ? JSON.parse(loggedInUser) : {}
  const globalClasses = useGlobalStyles()

  const { data, error: errorQuery, loading: loadingQuery } = useQuery(
    EVENTS_BY_OWNER,
    {
      variables: { id: organizerId }
    }
  )

  const eventsList =
    data &&
    data.eventsByOwner.events.map((event, index) => {
      return (
        <Grid key={index} item xs={12} sm={6} md={4} lg={3}>
          <Link
            underline="none"
            style={{ textDecoration: 'none' }}
            key={event._id}
            onClick={() => {
              localStorage.setItem('eventId', event._id)
              localStorage.setItem('eventImage', event.image)
              localStorage.setItem('eventName', event.name)
            }}
            to={`/events/${event.slug}`}>
            <EventCard key={event._id} event={event} />
          </Link>
        </Grid>
      )
    })

  return (
    <>
      <Box
        sx={{
          height: '160px',
          width: '100%',
          background: '#65A0B0', // You can set your own background color or image
          borderRadius: '0 0 40px 40px',
          marginBottom: 1,
          mt: -10
        }}
      />
      {/* Page content */}
      <Container fluid>
        <Box mt={-10}>
          {loadingQuery ? <div>Loading...</div> : null}
          {errorQuery ? <span>{errorQuery.message}</span> : null}
          {!loadingQuery && !errorQuery && (
            <Grid container spacing={2}>
              {eventsList}
            </Grid>
          )}
        </Box>
        {userType === 'ORGANIZER' && (
          <Box mt={6} className={globalClasses.flexRow}>
            <Button
              variant="contained"
              onClick={() => {
                setOwner(data.eventsByOwner._id)
                toggleModal()
              }}
              style={{
                backgroundColor: '#000', // Customize the button style
                color: '#65A0B0', // Customize the button text color
                borderRadius: 10
              }}
              startIcon={<AddIcon fill="#000" />}>
              Add New Event
            </Button>
          </Box>
        )}
        <Modal
          open={isModalVisible}
          onClose={toggleModal}
          style={{
            width: '65%',
            marginLeft: '18%',
            overflowY: 'auto'
          }}>
          <CreateEvent organizerId={owner} />
        </Modal>
      </Container>
    </>
  )
}

export default Event
