import React, { useState } from 'react';
import {
  Box,
  Typography,
  Input,
  Button,
  Container,
  Grid,
} from '@mui/material';
import Header from '../components/Headers/Header';
import {
  useQuery,
  gql
} from '@apollo/client';
import { getEventStatistics } from '../apollo'; // Replace with your queries
import useStyles from '../components/Option/styles';
import useGlobalStyles from '../utils/globalStyles';

const GET_EVENT_STATISTICS = gql`
  ${getEventStatistics} // Update with your query
`;

const Dashboard = (props) => {
  const userId = localStorage.getItem('userId'); // Change this to get the user ID from your context
  const initializeStartDate = () => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return d.toISOString().substr(0, 10);
  };

  const [stateData, setStateData] = useState({
    startingDate: initializeStartDate(),
    endingDate: new Date().toISOString().substr(0, 10),
  });

  const {
    data: eventData,
    error: errorEvent,
    loading: loadingEvent,
  } = useQuery(GET_EVENT_STATISTICS, {
    variables: {
      startingDate: stateData.startingDate.toString(),
      endingDate: stateData.endingDate.toString(),
      user: userId,
    },
  });

  const classes = useStyles();
  const globalClasses = useGlobalStyles();

  return (
    <>
      <Header />
      <Container className={globalClasses.flex} fluid>
        {errorEvent ? <span>{`Error! ${errorEvent.message}`}</span> : null}
        <Box container className={classes.container}>
          <Box className={classes.flexRow}>
            <Box item className={classes.heading}>
              <Typography variant="h6" className={classes.textWhite}>
                Graph Filter
              </Typography>
            </Box>
          </Box>

          <Box className={classes.form}>
            <form>
              <Grid container sx={{ textAlign: 'left' }}>
                <Grid item md={6} xs={12}>
                  <Typography sx={{ fontWeight: 'bold' }}>Start Date</Typography>
                  <Input
                    style={{ marginTop: -1 }}
                    type="date"
                    max={new Date().toISOString().substr(0, 10)}
                    onChange={(event) => {
                      setStateData({
                        ...stateData,
                        startingDate: event.target.value,
                      });
                    }}
                    value={stateData.startingDate}
                    disableUnderline
                    className={[globalClasses.input]}
                  />
                </Grid>
                <Grid item md={6} xs={12}>
                  <Typography sx={{ fontWeight: 'bold' }}>End Date</Typography>
                  <Input
                    style={{ marginTop: -1 }}
                    type="date"
                    max={new Date().toISOString().substr(0, 10)}
                    onChange={(event) => {
                      setStateData({
                        ...stateData,
                        endingDate: event.target.value,
                      });
                    }}
                    value={stateData.endingDate}
                    disableUnderline
                    className={[globalClasses.input]}
                  />
                </Grid>
              </Grid>
              <Button className={globalClasses.button}>Apply</Button>
            </form>
          </Box>
        </Box>
      </Container>
      {/* The rest of your Dashboard content here */}
    </>
  );
};

export default Dashboard;
