import React, { useState } from 'react';
import { useQuery, useMutation, gql } from '@apollo/client';
import { withTranslation } from 'react-i18next';

// core components
import Header from '../components/Headers/Header';
import { getEventDetails, deleteService } from '../apollo'; // Replace with your queries
import ServiceComponent from '../components/Service/Service';
import CustomLoader from '../components/Loader/CustomLoader';
import DataTable from 'react-data-table-component';
import orderBy from 'lodash/orderBy';
import { transformToNewline } from '../utils/stringManipulations';
import SearchBar from '../components/TableHeader/SearchBar';
import useGlobalStyles from '../utils/globalStyles';

import {
  Container,
  IconButton,
  Menu,
  MenuItem,
  Modal,
  Paper,
  Typography,
  ListItemIcon,
} from '@mui/material';

import { customStyles } from '../utils/tableCustomStyles';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import TableHeader from '../components/TableHeader';
import Alert from '../components/Alert';

const GET_SERVICES = gql`
  ${getEventDetails}
`;
const DELETE_SERVICE = gql`
  ${deleteService}
`;

const Service = (props) => {
  const [editModal, setEditModal] = useState(false);
  const [service, setService] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const onChangeSearch = (e) => setSearchQuery(e.target.value);
  const eventId = localStorage.getItem('eventId'); // Replace with your context or state variable

  const [/*mutate*/, { loading }] = useMutation(DELETE_SERVICE, {
    refetchQueries: [{ query: GET_SERVICES, variables: { id: eventId } }],
  });

  const { data, error: errorQuery, loading: loadingQuery, refetch } = useQuery(
    GET_SERVICES,
    {
      variables: {
        id: eventId,
      },
    }
  );

  const toggleModal = (service) => {
    setEditModal(!editModal);
    setService(service);
  };

  const propExists = (obj, path) => {
    return path.split('.').reduce((obj, prop) => {
      return obj && obj[prop] ? obj[prop] : '';
    }, obj);
  };

  const customSort = (rows, field, direction) => {
    const handleField = (row) => {
      if (field && isNaN(propExists(row, field))) {
        return propExists(row, field).toLowerCase();
      }
      return row[field];
    };
    return orderBy(rows, handleField, direction);
  };

  const columns = [
    {
      name: 'Title',
      selector: 'title',
      sortable: true,
    },
    {
      name: 'Description',
      sortable: true,
      selector: 'description',
      cell: (row) => <>{transformToNewline(row.description, 3)}</>,
    },
    {
      name: 'Category',
      sortable: true,
      selector: 'category.category',
      cell: (row) => <>{row.category}</>,
    },
    {
      name: 'Image',
      cell: (row) => (
        <>
          {!!row.image && (
            <img
              className="img-responsive"
              style={{ width: 30, height: 30, borderRadius: 15 }}
              src={row.image}
              alt="service image"
            />
          )}
          {!row.image && 'No Image'}
        </>
      ),
    },
    {
      name: 'Action',
      cell: (row) => <>{actionButtons(row)}</>,
    },
  ];

  const actionButtons = (row) => {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);

    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
      setAnchorEl(null);
    };

    return (
      <>
        <div>
          <IconButton
            aria-label="more"
            id="long-button"
            aria-haspopup="true"
            onClick={handleClick}
          >
            <MoreVertIcon fontSize="small" />
          </IconButton>
          <Paper>
            <Menu
              id="long-menu"
              MenuListProps={{
                'aria-labelledby': 'long-button',
              }}
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
            >
              <MenuItem
                onClick={(e) => {
                  e.preventDefault();
                  // Uncomment this for paid version
                  // toggleModal(row);
                  setIsOpen(true);
                  setTimeout(() => {
                    setIsOpen(false);
                  }, 5000);
                }}
                style={{ height: 25 }}
              >
                <ListItemIcon>
                  <EditIcon fontSize="small" style={{ color: 'green' }} />
                </ListItemIcon>
                <Typography color="green">Edit</Typography>
              </MenuItem>
              <MenuItem
                onClick={(e) => {
                  e.preventDefault();
                  // Uncomment this for paid version
                  // mutate({
                  //   variables: {
                  //     id: row._id,
                  //     eventId: eventId,
                  //     categoryId: row.categoryId,
                  //   },
                  // });
                  setIsOpen(true);
                  setTimeout(() => {
                    setIsOpen(false);
                  }, 5000);
                }}
                style={{ height: 25 }}
              >
                <ListItemIcon>
                  <DeleteIcon fontSize="small" style={{ color: 'red' }} />
                </ListItemIcon>
                <Typography color="red">Delete</Typography>
              </MenuItem>
            </Menu>
          </Paper>
        </div>
      </>
    );
  };

  const servicesList = (categories) => {
    const list = [];
    categories &&
      categories.forEach((category) => {
        if (category.services && category.services.length) {
          return category.services.map((item) => {
            list.push({
              ...item,
              category: category.title,
              categoryId: category._id,
              ...category,
              _id: item._id,
              title: item.title,
            });

            return {
              ...item,
              category: category.title,
              categoryId: category._id,
              ...category,
              _id: item._id,
              title: item.title,
            };
          });
        }
      });
    return list;
  };

  const regex =
    searchQuery.length > 2 ? new RegExp(searchQuery.toLowerCase(), 'g') : null;

  const filtered =
    searchQuery.length < 3
      ? servicesList(data && data.event.categories)
      : servicesList(data && data.event.categories).filter((service) => {
        return (
          service.title.toLowerCase().search(regex) > -1 ||
            service.description.toLowerCase().search(regex) > -1 ||
            service.category.toLowerCase().search(regex) > -1
        );
      });

  const globalClasses = useGlobalStyles();

  return (
    <>
      <Header />
      {/* Page content */}
      {isOpen && (
        <Alert
          message="This feature will be available after purchasing the product"
          severity="warning"
        />
      )}
      <Container className={globalClasses.flex} fluid>
        <ServiceComponent />
        {errorQuery && <span>Error! {errorQuery.message}</span>}
        {loadingQuery ? (
          <CustomLoader />
        ) : (
          <DataTable
            subHeader={true}
            subHeaderComponent={
              <SearchBar
                value={searchQuery}
                onChange={onChangeSearch}
                onClick={() => refetch()}
              />
            }
            title={<TableHeader title="Services" />}
            columns={columns}
            data={data && data.event ? filtered : {}}
            pagination
            progressPending={loading}
            progressComponent={<CustomLoader />}
            sortFunction={customSort}
            defaultSortField="title"
            customStyles={customStyles}
            selectableRows
            paginationIconLastPage=""
            paginationIconFirstPage=""
          />
        )}
        <Modal
          open={editModal}
          onClose={() => {
            toggleModal();
          }}
          style={{
            marginLeft: '13%',
            overflowY: 'auto',
          }}
        >
          <ServiceComponent service={service} />
        </Modal>
      </Container>
    </>
  );
};

export default withTranslation()(Service);
