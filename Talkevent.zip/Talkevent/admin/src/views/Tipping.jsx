/* eslint-disable react/display-name */
import React from 'react'
import { withTranslation } from 'react-i18next'
import { Container, Grid } from '@mui/material'
import EventTippingComponent from '../components/EventTipping/EventTipping' // Adjust component import
// core components
import Header from '../components/Headers/Header'
import useGlobalStyles from '../utils/globalStyles'
import { ReactComponent as EventTippingIcon } from '../assets/svg/svg/EventTipping.svg' // Adjust icon import

function EventTipping() {
  const globalClasses = useGlobalStyles()
  return (
    <>
      <Header />
      {/* Page content */}
      <Container className={globalClasses.flex} fluid>
        <Grid container>
          <Grid item order={{ xs: 2, md: 1 }}>
            <EventTippingComponent /> {/* Adjust component rendering */}
          </Grid>
          <Grid
            sx={{ display: { xs: 'none', lg: 'block' } }}
            item
            mt={5}
            order={{ xs: 1, lg: 2 }}>
            <EventTippingIcon /> {/* Adjust icon rendering */}
          </Grid>
        </Grid>
      </Container>
    </>
  )
}

export default withTranslation()(EventTipping)
