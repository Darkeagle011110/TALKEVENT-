/* eslint-disable react/display-name */
import React, { useState, useEffect } from 'react';
import { withTranslation } from 'react-i18next';
import {
  Container,
  IconButton,
  Menu,
  MenuItem,
  Modal,
  Paper,
  Typography,
  ListItemIcon,
} from '@mui/material';
import { gql, useQuery, useMutation } from '@apollo/client';
import Header from '../components/Headers/Header';
import EventComponent from '../components/Event/EventComponent'; // Replace with your Event component
import CustomLoader from '../components/Loader/CustomLoader';
import { getEvents, deleteEvent } from '../apollo'; // Update with the appropriate GraphQL queries
import DataTable from 'react-data-table-component';
import orderBy from 'lodash/orderBy';
import SearchBar from '../components/TableHeader/SearchBar';
import { customStyles } from '../utils/tableCustomStyles';
import useGlobalStyles from '../utils/globalStyles';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import TableHeader from '../components/TableHeader';
import Alert from '../components/Alert';

const GET_EVENTS = gql`
  ${getEvents}
`;

const DELETE_EVENT = gql`
  ${deleteEvent}
`;

const Events = (props) => {
  const [editModal, setEditModal] = useState(false);
  const [events, setEvent] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const onChangeSearch = (e) => setSearchQuery(e.target.value);

  const [/*mutate*/ { error, loading }] = useMutation(DELETE_EVENT, {
    refetchQueries: [{ query: GET_EVENTS }],
  });
  const { data, loading: loadingQuery, refetch } = useQuery(GET_EVENTS);
  const toggleModal = (event) => {
    setEditModal(!editModal);
    setEvent(event);
  };

  useEffect(() => {
    // Remove any specific local storage data
  }, []);

  const customSort = (rows, field, direction) => {
    const handleField = (row) => {
      if (row[field]) {
        return row[field].toLowerCase();
      }
      return row[field];
    };

    return orderBy(rows, handleField, direction);
  };

  const columns = [
    {
      name: 'Event Name',
      sortable: true,
      selector: 'eventName', // Update with the appropriate field
    },
    {
      name: 'Description',
      sortable: true,
      selector: 'description', // Update with the appropriate field
    },
    {
      name: 'Action',
      cell: (row) => <>{actionButtons(row)}</>,
    },
  ];
  const actionButtons = (row) => {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
      setAnchorEl(null);
    };
    return (
      <>
        <div>
          <IconButton
            aria-label="more"
            id="long-button"
            aria-haspopup="true"
            onClick={handleClick}
          >
            <MoreVertIcon fontSize="small" />
          </IconButton>
          <Paper>
            <Menu
              id="long-menu"
              MenuListProps={{
                'aria-labelledby': 'long-button',
              }}
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}
            >
              <MenuItem
                onClick={(e) => {
                  e.preventDefault();
                  // Uncomment this for edit functionality
                  // toggleModal(row);
                  setIsOpen(true);
                  setTimeout(() => {
                    setIsOpen(false);
                  }, 5000);
                }}
                style={{ height: 25 }}
              >
                <ListItemIcon>
                  <EditIcon fontSize="small" style={{ color: 'green' }} />
                </ListItemIcon>
                <Typography color="green">Edit</Typography>
              </MenuItem>
              <MenuItem
                onClick={(e) => {
                  e.preventDefault();
                  // Uncomment this for delete functionality
                  // mutate({ variables: { id: row._id } });
                  setIsOpen(true);
                  setTimeout(() => {
                    setIsOpen(false);
                  }, 2000);
                }}
                style={{ height: 25 }}
              >
                <ListItemIcon>
                  <DeleteIcon fontSize="small" style={{ color: 'red' }} />
                </ListItemIcon>
                <Typography color="red">Delete</Typography>
              </MenuItem>
            </Menu>
          </Paper>
        </div>
      </>
    );
  };

  const regex =
    searchQuery.length > 2 ? new RegExp(searchQuery.toLowerCase(), 'g') : null;

  const filtered =
    searchQuery.length < 3
      ? data && data.events
      : data &&
        data.events.filter((event) => {
          return (
            event.eventName.toLowerCase().search(regex) > -1 ||
            event.description.toLowerCase().search(regex) > -1
          );
        });

  const globalClasses = useGlobalStyles();

  return (
    <>
      <Header />
      {/* Page content */}
      <Container className={globalClasses.flex} fluid>
        <EventComponent /> {/* Update with your Event component */}
        {/* Table */}
        {isOpen && (
          <Alert
            message="This feature will be available after purchasing the product"
            severity="warning"
          />
        )}
        {error ? <span>{`Error! ${error.message}`}</span> : null}
        {loading ? <CustomLoader /> : null}
        <DataTable
          subHeader={true}
          subHeaderComponent={
            <SearchBar
              value={searchQuery}
              onChange={onChangeSearch}
              onClick={() => refetch()}
            />
          }
          title={<TableHeader title="Events" />} // Update with your title
          columns={columns}
          data={filtered}
          pagination
          progressPending={loadingQuery}
          progressComponent={<CustomLoader />}
          sortFunction={customSort}
          defaultSortField="eventName"
          customStyles={customStyles}
          selectableRows
        />
        <Modal
          style={{
            width: '70%',
            marginLeft: '15%',
            overflowY: 'auto',
          }}
          open={editModal}
          onClose={() => {
            toggleModal();
          }}
        >
          <EventComponent event={events} closeModal={setEditModal} />
        </Modal>
      </Container>
    </>
  );
};

export default withTranslation()(Events);
