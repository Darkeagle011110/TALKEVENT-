import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { PrivateRoute } from './PrivateRoute'; // Import the PrivateRoute component
import Home from './Home';
import Dashboard from './Dashboard';
import Login from './Login';

const App = () => {
  return (
    <Router>
      <Switch>
        <Route path="/auth/login" component={Login} />
        <PrivateRoute path="/dashboard" component={Dashboard} />
        <PrivateRoute path="/" component={Home} />
      </Switch>
    </Router>
  );
};

export default App;
