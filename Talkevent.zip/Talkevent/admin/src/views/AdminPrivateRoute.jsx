import React from 'react';
import { Redirect, Route } from 'react-router-dom';

export const EventPrivateRoute = ({ component: Component, ...rest }) => (
  <Route
    {...rest}
    render={props =>
      localStorage.getItem('user-talkevent') ? (
        // Check the user's userType to allow access
        JSON.parse(localStorage.getItem('user-talkevent')).userType === 'ADMIN' ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{
              pathname: '/',
              state: { from: props.location }
            }}
          />
        )
      ) : (
        <Redirect
          to={{
            pathname: '/auth/login',
            state: { from: props.location }
          }}
        />
      )
    }
  />
);
