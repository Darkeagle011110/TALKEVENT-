import React, { useState, useRef } from 'react';
import { withTranslation } from 'react-i18next';
import Header from '../components/Headers/Header';
import { useQuery, useMutation, gql } from '@apollo/client';
import { getOrganizerProfile, editOrganizer } from '../apollo'; // Update GraphQL queries
import { CLOUDINARY_UPLOAD_URL, CLOUDINARY_PROFILE } from '../config/constants'; // Update image upload constants
import useStyles from '../components/Organizer/styles'; // Create organizer-specific styles
import useGlobalStyles from '../utils/globalStyles';
import { Box, Alert, Typography, Button, Input } from '@mui/material';
import { Container } from '@mui/system';
import CustomLoader from '../components/Loader/CustomLoader';

const GET_PROFILE = gql`
  ${getOrganizerProfile} // Update with your GraphQL query
`;

const EDIT_ORGANIZER = gql`
  ${editOrganizer} // Update with your GraphQL mutation
`;

const OrganizerProfile = () => {
  const organizerId = localStorage.getItem('organizerId'); // Adjust the way to get the organizer's ID

  const [imgUrl, setImgUrl] = useState('');
  // Define state variables for validation errors and success messages

  // Add validation error and success states here

  const onCompleted = (data) => {
    // Reset validation errors and show a success message
  };

  const onError = ({ graphQLErrors, networkError }) => {
    // Handle errors and show them to the user
  };

  const hideAlert = () => {
    // Hide validation and success messages
  };

  const { data, error: errorQuery, loading: loadingQuery } = useQuery(
    GET_PROFILE,
    {
      variables: { id: organizerId }, // Use the organizer's ID to fetch their profile
    }
  );

  const [mutate, { loading }] = useMutation(EDIT_ORGANIZER, {
    onError,
    onCompleted,
  });

  const formRef = useRef(null);

  const selectImage = (event, state) => {
    // Handle image selection and conversion to base64
  };

  const imageToBase64 = (imgUrl) => {
    // Convert the image to base64
  };

  const uploadImageToCloudinary = async () => {
    // Upload the image to Cloudinary and return the URL
  };

  const onSubmitValidation = (data) => {
    // Perform validation and show errors if necessary

    // Update the validation logic based on your requirements
  };

  const classes = useStyles(); // Use organizer-specific styles
  const globalClasses = useGlobalStyles();

  return (
    <>
      <Header />
      <Container className={globalClasses.flex} fluid>
        <Box container className={classes.container}>
          <Box style={{ alignItems: 'start' }} className={classes.flexRow}>
            <Box item className={classes.heading2}>
              <Typography variant="h6" className={classes.textWhite}>
                Update Organizer Profile
              </Typography>
            </Box>
          </Box>
          {errorQuery && <span>{errorQuery.message}</span>}
          {loadingQuery ? (
            <CustomLoader />
          ) : (
            <Box className={classes.form}>
              <form ref={formRef}>
                {/* Organizer profile form fields (name, address, etc.) */}
              </form>
            </Box>
          )}
        </Box>
      </Container>
    </>
  );
};

export default withTranslation()(OrganizerProfile);
