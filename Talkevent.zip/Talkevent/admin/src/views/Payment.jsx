import React from 'react';
import { useQuery, gql } from '@apollo/client';
import { withTranslation } from 'react-i18next';
import { Container, Box, Typography, Button } from '@mui/material';
import Header from '../components/Headers/Header';
import { SERVER_URL } from '../config/constants';
import { getOrganizerProfile } from '../apollo'; // Adjust the query
import useGlobalStyles from '../utils/globalStyles';
import useStyles from '../components/styles';

const ORGANIZER = gql`
  ${getOrganizerProfile}
`;

const Payment = () => {
  const organizerId = localStorage.getItem('organizerId'); // Replace with the organizer's identifier

  const { data, error: errorQuery, loading: loadingQuery } = useQuery(
    ORGANIZER,
    {
      variables: { id: organizerId }, // Adjust the query variables
    }
  );

  const submitStripeDetails = () => {
    fetch(SERVER_URL + '/stripe/account', {
      method: 'POST',
      body: JSON.stringify({ organizerId }), // Adjust the data being sent
      headers: {
        'content-type': 'application/json',
      },
    })
      .then((response) => response.json())
      .then((data) => {
        window.location = data.url;
      })
      .catch((error) => {
        console.log('error', error);
      });
  };

  const globalClasses = useGlobalStyles();
  const classes = useStyles();

  return (
    <>
      <Header />
      <Container className={globalClasses.flex}>
        <Box container className={classes.container}>
          <Box className={classes.flexRow}>
            <Box item className={classes.heading2}>
              <Typography variant="h6" className={classes.textWhite}>
                Payment Settings
              </Typography>
            </Box>
          </Box>

          <Box className={classes.form}>
            {loadingQuery && <span>Loading...</span>}
            {errorQuery && <span>{errorQuery.message}</span>}
            {data && data.organizer.stripeDetailsSubmitted && (
              <Typography>Stripe Details Attached</Typography>
            )}
            <Box mt={3} mb={3}>
              <Button
                className={globalClasses.button}
                disabled={loadingQuery}
                onClick={submitStripeDetails}>
                {data && data.organizer.stripeDetailsSubmitted
                  ? 'Edit Stripe details'
                  : 'Submit Stripe Details'}
              </Button>
            </Box>
          </Box>
        </Box>
      </Container>
    </>
  );
};

export default withTranslation()(Payment);
