import React, { useState, useEffect } from 'react';
import { withTranslation } from 'react-i18next';
import { gql, useMutation, useQuery } from '@apollo/client';
import Header from '../components/Headers/Header';
import VendorComponent from '../components/Vendor/Vendor'; // Update or create the VendorComponent component
import CustomLoader from '../components/Loader/CustomLoader';
import { getEventOrganizers, deleteEventOrganizer } from '../apollo'; // Define the appropriate GraphQL queries and mutations for event organizers
import DataTable from 'react-data-table-component';
import orderBy from 'lodash/orderBy';
import SearchBar from '../components/TableHeader/SearchBar';
import { customStyles } from '../utils/tableCustomStyles';
import useGlobalStyles from '../utils/globalStyles';
import {
  Container,
  Button,
  Grid,
  Modal,
  MenuItem,
  IconButton,
  Menu,
  ListItemIcon,
  Typography,
  Paper,
  Alert
} from '@mui/material';
import { ReactComponent as VendorIcon } from '../assets/svg/svg/Vendors.svg'; // You can create an appropriate icon for event organizers
import MoreVertIcon from '@mui/icons-material/MoreVert';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import TableHeader from '../components/TableHeader';

const GET_EVENT_ORGANIZERS = gql`
  ${getEventOrganizers}
`; // Update with your GraphQL query for event organizers

const DELETE_EVENT_ORGANIZER = gql`
  ${deleteEventOrganizer}
`; // Update with your GraphQL mutation for deleting event organizers

const EventOrganizers = (props) => {
  const [editModal, setEditModal] = useState(false);
  const [eventOrganizers, setEventOrganizer] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const onChangeSearch = (e) => setSearchQuery(e.target.value);
  const globalClasses = useGlobalStyles();

  const {
    loading: loadingQuery,
    error: errorQuery,
    data,
    refetch
  } = useQuery(GET_EVENT_ORGANIZERS);

  const [/*mutate*/, { loading }] = useMutation(DELETE_EVENT_ORGANIZER, {
    refetchQueries: [{ query: GET_EVENT_ORGANIZERS }]
  });

  const regex =
    searchQuery.length > 2 ? new RegExp(searchQuery.toLowerCase(), 'g') : null;

  const filtered =
    searchQuery.length < 3
      ? data && data.eventOrganizers
      : data &&
        data.eventOrganizers.filter((organizer) => {
          return organizer.email.toLowerCase().search(regex) > -1;
        });

  const toggleModal = (organizer) => {
    setEditModal(!editModal);
    setEventOrganizer(organizer);
  };

  useEffect(() => {
    localStorage.removeItem('restaurant_id');
  }, []);

  const customSort = (rows, field, direction) => {
    const handleField = (row) => {
      if (row[field]) {
        return row[field].toLowerCase();
      }

      return row[field];
    };

    return orderBy(rows, handleField, direction);
  };

  const columns = [
    {
      name: 'Email',
      sortable: true,
      selector: 'email'
    },
    {
      name: 'Total Events',
      sortable: true,
      cell: (row) => <>{row.events.length}</>
    },
    {
      name: 'Action',
      cell: (row) => <>{actionButtons(row)}</>
    }
  ];

  const actionButtons = (row) => {
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);

    const handleClick = (event) => {
      setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
      setAnchorEl(null);
    };

    return (
      <>
        <Button
          size="20px"
          variant="contained"
          sx={{
            color: 'black',
            fontWeight: 'bold',
            backgroundColor: '#90EA93',
            padding: 0,
            height: '15px',
            fontSize: '7px',
            '&:hover': {
              color: '#fff'
            }
          }}
          onClick={(e) => {
            e.preventDefault();
            localStorage.setItem('eventOrganizerId', row._id);
            // Redirect to a page showing the events organized by this organizer
            props.history.push({
              pathname: '/events',
              state: { organizerId: row._id }
            });
          }}>
          Events
        </Button>
        <div>
          <IconButton
            aria-label="more"
            id="long-button"
            aria-haspopup="true"
            onClick={handleClick}>
            <MoreVertIcon fontSize="small" />
          </IconButton>
          <Paper>
            <Menu
              id="long-menu"
              MenuListProps={{
                'aria-labelledby': 'long-button'
              }}
              anchorEl={anchorEl}
              open={open}
              onClose={handleClose}>
              <MenuItem
                onClick={(e) => {
                  e.preventDefault();
                  setIsOpen(true);
                  setTimeout(() => {
                    setIsOpen(false);
                  }, 5000);
                  // Uncomment this for paid version: toggleModal(row)
                }}
                style={{ height: 25 }}>
                <ListItemIcon>
                  <EditIcon fontSize="small" style={{ color: 'green' }} />
                </ListItemIcon>
                <Typography color="green">Edit</Typography>
              </MenuItem>
              <MenuItem
                onClick={(e) => {
                  e.preventDefault();
                  setIsOpen(true);
                  setTimeout(() => {
                    setIsOpen(false);
                  }, 5000);
                  // Uncomment this for paid version: mutate({ variables: { id: row._id } })
                }}
                style={{ height: 25 }}>
                <ListItemIcon>
                  <DeleteIcon fontSize="small" style={{ color: 'red' }} />
                </ListItemIcon>
                <Typography color="red">Delete</Typography>
              </MenuItem>
            </Menu>
          </Paper>
        </div>
      </>
    );
  };

  return (
    <>
      <Header />
      {isOpen && (
        <Alert
          message="This feature will be available after purchasing the product"
          severity="warning"
        />
      )}
      {/* Page content */}
      <Container className={globalClasses.flex}>
        <Grid container>
          <Grid item order={{ xs: 2, lg: 1 }}>
            <VendorComponent />
          </Grid>
          <Grid
            sx={{ display: { xs: 'none', lg: 'block' } }
            item
            mt={5}
            ml={-2}
            order={{ xs: 1, lg: 2 }}>
            <VendorIcon />
          </Grid>
        </Grid>
        {errorQuery ? <span> `Error! ${errorQuery.message}`</span> : null}
        {loadingQuery ? (
          <CustomLoader />
        ) : (
          <DataTable
            subHeader={true}
            subHeaderComponent={
              <SearchBar
                value={searchQuery}
                onChange={onChangeSearch}
                onClick={() => refetch()}
              />
            }
            title={<TableHeader title="Event Organizers" />}
            columns={columns}
            data={filtered}
            pagination
            progressPending={loading}
            progressComponent={<CustomLoader />}
            sortFunction={customSort}
            defaultSortField="email"
            customStyles={customStyles}
            selectableRows
          />
        )}
        <Modal
          open={editModal}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
          onClose={() => {
            toggleModal();
          }}>
          <VendorComponent vendor={eventOrganizers} />
        </Modal>
      </Container>
    </>
  );
};

export default withTranslation()(EventOrganizers);
