import React, { useState } from 'react'
import { withTranslation } from 'react-i18next'
import { Container } from '@mui/material'
import Header from '../components/Headers/Header'
import DataTable from 'react-data-table-component'
import orderBy from 'lodash/orderBy'
import CustomLoader from '../components/Loader/CustomLoader'
import { useQuery, gql } from '@apollo/client'
import useGlobalStyles from '../utils/globalStyles'
import SearchBar from '../components/TableHeader/SearchBar'
import { customStyles } from '../utils/tableCustomStyles'
import TableHeader from '../components/TableHeader'

const GET_EVENT_REVIEWS = gql`
  query GetEventReviews($eventId: ID!) {
    event(id: $eventId) {
      id
      title
      reviews {
        id
        user {
          name
          email
        }
        description
        rating
      }
    }
  }
`

const Ratings = props => {
  const [searchQuery, setSearchQuery] = useState('')
  const onChangeSearch = e => setSearchQuery(e.target.value)
  const eventId = localStorage.getItem('eventId') // You should set the eventId based on the selected event

  const { data, error: errorQuery, loading: loadingQuery } = useQuery(GET_EVENT_REVIEWS, {
    variables: { eventId },
  })

  const columns = [
    {
      name: 'Name',
      sortable: true,
      selector: 'user.name',
      cell: row => <>{row.user.name}</>,
    },
    {
      name: 'Email',
      sortable: true,
      selector: 'user.email',
      cell: row => <>{row.user.email}</>,
    },
    {
      name: 'Review',
      sortable: true,
      selector: 'description',
      cell: row => <>{row.description}</>,
    },
    {
      name: 'Ratings',
      sortable: true,
      selector: 'rating',
      cell: row => <>{row.rating}</>,
    },
  ]

  const customSort = (rows, field, direction) => {
    const handleField = row => {
      if (field && isNaN(row[field])) {
        return row[field].toLowerCase()
      }

      return row[field]
    }

    return orderBy(rows, handleField, direction)
  }

  const handleSort = (column, sortDirection) =>
    console.log(column.selector, sortDirection, column)

  const regex =
    searchQuery.length > 2 ? new RegExp(searchQuery.toLowerCase(), 'g') : null
  const filtered =
    searchQuery.length < 3
      ? data && data.event.reviews
      : data &&
        data.event.reviews.filter(review => {
          return (
            review.user.name.toLowerCase().search(regex) > -1 ||
            review.user.email.toLowerCase().search(regex) > -1
          )
        })
  const globalClasses = useGlobalStyles()

  return (
    <>
      <Header />
      {/* Page content */}
      <Container className={globalClasses.flex} fluid>
        {errorQuery && (
          <tr>
            <td>{`Error! ${errorQuery.message}`}</td>
          </tr>
        )}
        {loadingQuery ? (
          <CustomLoader />
        ) : (
          <DataTable
            title={<TableHeader title="Event Ratings and Reviews" />}
            subHeader={true}
            subHeaderComponent={
              <SearchBar value={searchQuery} onChange={onChangeSearch} />
            }
            columns={columns}
            data={filtered}
            pagination
            progressPending={loadingQuery}
            progressComponent={<CustomLoader />}
            onSort={handleSort}
            sortFunction={customSort}
            defaultSortField="user.name"
            customStyles={customStyles}
            selectableRows
            paginationIconLastPage=""
            paginationIconFirstPage=""
          />
        )}
      </Container>
    </>
  )
}

export default withTranslation()(Ratings)
