import React, { useState } from 'react';
import { useQuery, useMutation, gql } from '@apollo/client';
import CustomLoader from '../components/Loader/CustomLoader';
import DataTable from 'react-data-table-component';
import Header from '../components/Headers/Header';
import { Box, Container, MenuItem, Select } from '@mui/material';
import { customStyles } from '../utils/tableCustomStyles';
import useGlobalStyles from '../utils/globalStyles';
import SearchBar from '../components/TableHeader/SearchBar';
import { ReactComponent as WithdrawIcon } from '../assets/svg/svg/WithdrawRequest.svg';
import TableHeader from '../components/TableHeader';

const GET_WITHDRAW_REQUESTS = gql`
  query GetWithdrawRequests {
    getAllWithdrawRequests {
      data {
        _id
        requestId
        rider {
          name
        }
        requestAmount
        requestTime
        status
      }
    }
  }
`;

const UPDATE_WITHDRAW_REQUEST_STATUS = gql`
  mutation UpdateWithdrawRequestStatus($id: ID!, $status: String!) {
    updateWithdrawReqStatus(id: $id, status: $status) {
      _id
      status
    }
  }
`;

export default function WithdrawRequest() {
  const [searchQuery, setSearchQuery] = useState('');
  const onChangeSearch = (e) => setSearchQuery(e.target.value);
  const { loading, error, data } = useQuery(GET_WITHDRAW_REQUESTS);
  const [updateStatus] = useMutation(UPDATE_WITHDRAW_REQUEST_STATUS);

  const handleSort = (column, sortDirection) =>
    console.log(column.selector, sortDirection);

  const columns = [
    {
      name: 'Request ID',
      selector: 'requestId',
    },
    {
      name: 'Rider',
      sortable: true,
      selector: 'rider.name',
    },
    {
      name: 'Amount',
      selector: 'requestAmount',
    },
    {
      name: 'Date',
      selector: 'requestTime',
      cell: (row) => <>{new Date(row.requestTime).toDateString()}</>,
    },
    {
      name: 'Status',
      selector: 'status',
      cell: (row) => (
        <div>
          {row.status}
          <br />
          {updateRequestStatus(row)}
        </div>
      ),
    },
  ];

  const regex =
    searchQuery.length > 2 ? new RegExp(searchQuery.toLowerCase(), 'g') : null;
  const filtered =
    searchQuery.length < 3
      ? data && data.getAllWithdrawRequests.data
      : data &&
        data.getAllWithdrawRequests.data.filter((request) => {
          return (
            request.requestId.toLowerCase().search(regex) > -1 ||
            request.rider.name.toLowerCase().search(regex) > -1
          );
        });

  const updateRequestStatus = (row) => {
    return (
      <>
        <Select
          id="input-status"
          name="input-status"
          displayEmpty
          inputProps={{ 'aria-label': 'Without label' }}
          defaultValue={row.status}
          value={row.status}
          className={globalClasses.selectInput}
        >
          <MenuItem style={{ color: 'black' }} value={''}>
            Status
          </MenuItem>
          <MenuItem
            style={{ color: 'black' }}
            value={''}
            onClick={() => {
              if (row.status !== 'REQUESTED') {
                updateStatus({
                  variables: {
                    id: row._id,
                    status: 'REQUESTED',
                  },
                });
              }
            }}
          >
            REQUESTED
          </MenuItem>
          <MenuItem
            style={{ color: 'black' }}
            value={''}
            onClick={() => {
              if (row.status !== 'TRANSFERRED') {
                updateStatus({
                  variables: {
                    id: row._id,
                    status: 'TRANSFERRED',
                  },
                });
              }
            }}
          >
            TRANSFERRED
          </MenuItem>
          <MenuItem
            style={{ color: 'black' }}
            value={''}
            onClick={() => {
              if (row.status !== 'CANCELLED') {
                updateStatus({
                  variables: {
                    id: row._id,
                    status: 'CANCELLED',
                  },
                });
              }
            }}
          >
            CANCELLED
          </MenuItem>
        </Select>
      </>
    );
  };
  const globalClasses = useGlobalStyles();

  return (
    <>
      <Header />
      <Box className={globalClasses.flexRow} mb={3}>
        <WithdrawIcon />
      </Box>
      <Container className={globalClasses.flex} fluid>
        {error ? <span> `Error! ${error.message}`</span> : null}
        {loading ? (
          <CustomLoader />
        ) : (
          <DataTable
            subHeader={true}
            subHeaderComponent={
              <SearchBar
                value={searchQuery}
                onChange={onChangeSearch}
                // onClick={() => refetch()}
              />
            }
            title={<TableHeader title="Withdraw Requests" />}
            columns={columns}
            data={filtered}
            pagination
            progressPending={loading}
            progressComponent={<CustomLoader />}
            onSort={handleSort}
            selectableRows
            customStyles={customStyles}
          />
        )}
      </Container>
    </>
  );
}
