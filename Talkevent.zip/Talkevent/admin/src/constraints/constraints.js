import { validate } from 'validate.js';

const constraints = {
  eventTitle: {
    presence: {
      allowEmpty: false,
      message: '^Event title is required',
    },
    length: {
      maximum: 255,
      message: '^Event title is too long',
    },
  },
  eventDescription: {
    presence: {
      allowEmpty: false,
      message: '^Event description is required',
    },
    length: {
      maximum: 1000,
      message: '^Event description is too long',
    },
  },
  eventCategory: {
    presence: {
      allowEmpty: false,
      message: '^Please select a category for the event',
    },
  },
  eventLocation: {
    presence: {
      allowEmpty: false,
      message: '^Event location is required',
    },
    length: {
      maximum: 255,
      message: '^Event location is too long',
    },
  },
  eventDate: {
    presence: {
      allowEmpty: false,
      message: '^Event date is required',
    },
    date: {
      format: 'YYYY-MM-DD',
      message: '^Invalid date format (YYYY-MM-DD)',
    },
  },
  eventTime: {
    presence: {
      allowEmpty: false,
      message: '^Event time is required',
    },
    format: {
      pattern: /^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/,
      message: '^Invalid time format (HH:MM)',
    },
  },
  eventPrice: {
    presence: {
      allowEmpty: false,
      message: '^Event price is required',
    },
    numericality: {
      greaterThan: 0,
      message: '^Event price must be greater than 0',
    },
  },
  eventCapacity: {
    presence: {
      allowEmpty: false,
      message: '^Event capacity is required',
    },
    numericality: {
      onlyInteger: true,
      greaterThan: 0,
      message: '^Event capacity must be a positive integer',
    },
  },
  eventImage: {
    presence: {
      allowEmpty: false,
      message: '^Event image is required',
    },
  },
};

export const validateEvent = (values) => {
  return validate(values, constraints) || {};
};
