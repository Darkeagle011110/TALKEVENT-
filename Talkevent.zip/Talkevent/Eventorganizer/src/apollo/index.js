import AsyncStorage from '@react-native-async-storage/async-storage'
import {
  ApolloClient,
  InMemoryCache,
  ApolloLink,
  split,
  concat,
  Observable,
  createHttpLink
} from '@apollo/client'
import { WebSocketLink } from '@apollo/client/link/ws'
import {
  getMainDefinition,
  offsetLimitPagination
} from '@apollo/client/utilities'

import { getTalkEventEnvVars } from '../../talkEventEnvironment'
const { TALK_EVENT_GRAPHQL_URL, TALK_EVENT_WS_GRAPHQL_URL } = getTalkEventEnvVars()

export let talkEventClientRef = null

function setupTalkEventApolloClient() {
  const cache = new InMemoryCache({
    typePolicies: {
      Query: {
        fields: {
          eventOrganizerListings: offsetLimitPagination(),
          eventOrganizerProfile: {
            merge(existing, incoming) {
              return incoming
            }
          },
          eventBookingRequests: offsetLimitPagination(),
          _id: {
            keyArgs: ['id']
          }
        }
      }
    }
  })

  const httpLink = createHttpLink({
    uri: TALK_EVENT_GRAPHQL_URL
  })
  const wsLink = new WebSocketLink({
    uri: TALK_EVENT_WS_GRAPHQL_URL,
    options: {
      reconnect: true
    }
  })

  const request = async operation => {
    const token = await AsyncStorage.getItem('event-organizer-token')

    operation.setContext({
      headers: {
        authorization: token ? `Bearer ${token}` : ''
      }
    })
  }

  const requestLink = new ApolloLink(
    (operation, forward) =>
      new Observable(observer => {
        let handle
        Promise.resolve(operation)
          .then(oper => request(oper))
          .then(() => {
            handle = forward(operation).subscribe({
              next: observer.next.bind(observer),
              error: observer.error.bind(observer),
              complete: observer.complete.bind(observer)
            })
          })
          .catch(observer.error.bind(observer))

        return () => {
          if (handle) handle.unsubscribe()
        }
      })
  )

  const terminatingLink = split(({ query }) => {
    const { kind, operation } = getMainDefinition(query)
    return kind === 'OperationDefinition' && operation === 'subscription'
  }, wsLink)

  const client = new ApolloClient({
    link: concat(ApolloLink.from([terminatingLink, requestLink]), httpLink),
    cache,
    resolvers: {}
  })
  talkEventClientRef = client
  return client
}

export default setupTalkEventApolloClient
