export const eventOrganizerLogin = `
  mutation EventOrganizerLogin($email: String, $password: String, $notificationToken: String) {
    eventOrganizerLogin(email: $email, password: $password, notificationToken: $notificationToken) {
      organizerId
      token
    }
  }
`

export const updateEventStatus = `
  mutation UpdateEventStatus($id: String!, $status: String!) {
    updateEventStatus(id: $id, status: $status) {
      _id
      eventStatus
    }
  }
`

export const createEventListing = `
  mutation CreateEventListing($listingInput: EventListingInput) {
    createEventListing(listingInput: $listingInput) {
      _id
      eventName
      eventDate
      organizer {
        _id
        name
        email
      }
    }
  }
`

export const updateOrganizerLocation = `
  mutation UpdateOrganizerLocation($latitude: String!, $longitude: String!) {
    updateOrganizerLocation(latitude: $latitude, longitude: $longitude) {
      _id
    }
  }
`

export const toggleAvailability = `
  mutation ToggleOrganizerAvailability($id: String) {
    toggleAvailability(id: $id) {
      _id
    }
  }
`

export const createEventBookingRequest = `
  mutation CreateEventBookingRequest($bookingInput: EventBookingInput) {
    createEventBookingRequest(bookingInput: $bookingInput) {
      _id
      requestId
      requestTime
      status
      event {
        eventName
        eventDate
      }
    }
  }
`

export const createPayment = `
  mutation CreatePayment($paymentInput: PaymentInput) {
    createPayment(paymentInput: $paymentInput) {
      organizer {
        _id
        email
      }
      event {
        _id
        eventName
      }
      paymentStatus
      paymentMethod
      paymentTime
      _id
    }
  }
`

export const sendEventChatMessage = `
  mutation SendEventChatMessage($eventId: ID!, $messageInput: ChatMessageInput!) {
    sendEventChatMessage(message: $messageInput, eventId: $eventId) {
      success
      message
      data {
        id
        message
        user {
          id
          name
        }
        createdAt
      }
    }
  }
`
