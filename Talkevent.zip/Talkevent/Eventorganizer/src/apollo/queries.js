export const eventOrganizerProfile = `
query EventOrganizer($id: String) {
  eventOrganizer(id: $id) {
    _id
    name
    email
    accountNumber
    username
    available
    events {
      _id
      eventName
      eventDate
    }
    currentWalletAmount
    totalWalletAmount
    withdrawnWalletAmount
  }
}
`

export const eventOrganizerConfiguration = `
query EventOrganizerConfiguration {
  eventOrganizerConfiguration {
    _id
    currency
    currencySymbol
  }
}
`

export const eventOrganizerEvents = `
query EventOrganizerEvents {
  eventOrganizerEvents {
    _id
    eventName
    eventDate
    organizer {
      _id
      name
    }
  }
}
`

export const eventOrganizerLocation = `
query EventOrganizerLocation {
  eventOrganizerLocation {
    _id
    latitude
    longitude
  }
}
`

export const eventOrganizerAvailability = `
query EventOrganizerAvailability($id: String) {
  eventOrganizerAvailability(id: $id) {
    _id
    isAvailable
  }
}
`

export const eventBookingRequests = `
query EventBookingRequests {
  eventBookingRequests {
    _id
    requestId
    requestTime
    status
    event {
      eventName
      eventDate
    }
  }
}
`

export const eventPayment = `
query EventPayment {
  eventPayment {
    _id
    event {
      _id
      eventName
    }
    paymentStatus
    paymentMethod
    paymentTime
  }
}
`

export const eventChat = `
query EventChat($eventId: ID!) {
  eventChat(eventId: $eventId) {
    id
    message
    user {
      id
      name
    }
    createdAt
  }
}
`
