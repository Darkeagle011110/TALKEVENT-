export const eventSubscriptionOrder = `
subscription EventSubscriptionOrder($eventId: ID) {
  eventSubscriptionOrder(eventId: $eventId) {
    _id
    orderStatus
    event {
      _id
      eventName
    }
  }
}
`

export const zoneSubscriptionOrders = `
subscription ZoneSubscriptionOrders($zoneId: ID) {
  zoneSubscriptionOrders(zoneId: $zoneId) {
    _id
    origin
    order {
      _id
      orderId
      createdAt
      acceptedAt
      expectedTime
      pickedAt
      assignedAt
      isPickedUp
      deliveredAt
      deliveryCharges
      restaurant {
        _id
        name
        address
        location {
          coordinates
        }
      }
      deliveryAddress {
        location {
          coordinates
        }
        deliveryAddress
        label
        details
      }
      items {
        _id
        title
        food
        description
        quantity
        variation {
          _id
          title
          price
        }
        addons {
          _id
          options {
            _id
            title
            price
          }
          title
          description
          quantityMinimum
          quantityMaximum
        }
        isActive
        createdAt
      }
      user {
        _id
        name
        phone
      }
      paymentMethod
      paidAmount
      orderAmount
      paymentStatus
      orderStatus
      tipping
      taxationAmount
      reason
      isRiderRinged
      preparationTime
      rider {
        _id
        name
        username
      }
    }
  }
}
`

export const eventSubscriptionAssignRider = `
subscription EventSubscriptionAssignRider($eventId: ID) {
  eventSubscriptionAssignRider(eventId: $eventId) {
    order {
      _id
      orderId
      createdAt
      acceptedAt
      pickedAt
      isPickedUp
      deliveredAt
      expectedTime
      deliveryCharges
      restaurant {
        _id
        name
        address
        location {
          coordinates
        }
      }
      deliveryAddress {
        location {
          coordinates
        }
        deliveryAddress
        label
        details
      }
      items {
        _id
        title
        food
        description
        quantity
        variation {
          _id
          title
          price
        }
        addons {
          _id
          options {
            _id
            title
            price
          }
          title
          description
          quantityMinimum
          quantityMaximum
        }
        isActive
        createdAt
      }
      user {
        _id
        name
        phone
      }
      paymentMethod
      paidAmount
      orderAmount
      paymentStatus
      orderStatus
      tipping
      taxationAmount
      reason
      isRiderRinged
      preparationTime
      rider {
        _id
        name
        username
      }
    }
    origin
  }
}
`

export const eventSubscriptionNewMessage = `
subscription EventSubscriptionNewMessage($eventId: ID) {
  eventSubscriptionNewMessage(eventId: $eventId) {
    id
    message
    user {
      id
      name
    }
    createdAt
  }
}
