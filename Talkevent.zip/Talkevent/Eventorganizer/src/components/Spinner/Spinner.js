import React from 'react';
import { ActivityIndicator } from 'react-native';
import colors from '../../utilities/colors';

function EventBookingSpinner(props) {
  return (
    <ActivityIndicator
      size="large"
      color={props.spinnerColor ?? colors.primary}
      style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
    />
  );
}

export default EventBookingSpinner;
