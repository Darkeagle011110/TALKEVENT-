import React from 'react';
import { Text, StyleSheet } from 'react-native';
import colors from '../../utilities/colors';

const TextDefault = (props) => {
  const textColor = props.textColor ? props.textColor : colors.fontMainColor;
  const defaultStyle = StyleSheet.flatten([
    { color: textColor },
    { fontFamily: 'your-font-family' }, // Set your desired font family here
    { fontSize: 16 }, // Set your desired default font size
  ]);
  const customStyles = [defaultStyle];

  if (props.bold) customStyles.push({ fontWeight: 'bold' });
  if (props.bolder) customStyles.push({ fontWeight: 'bolder' });
  if (props.center) customStyles.push({ textAlign: 'center' });
  if (props.right) customStyles.push({ textAlign: 'right' });
  if (props.small) customStyles.push({ fontSize: 12 }); // Set your desired small font size
  if (props.XL) customStyles.push({ fontSize: 24 }); // Set your desired extra-large font size
  if (props.H5) customStyles.push({ fontSize: 20 }); // Set your desired H5 font size
  if (props.H4) customStyles.push({ fontSize: 24 }); // Set your desired H4 font size
  if (props.H3) customStyles.push({ fontSize: 28 }); // Set your desired H3 font size
  if (props.H2) customStyles.push({ fontSize: 32 }); // Set your desired H2 font size
  if (props.H1) customStyles.push({ fontSize: 36 }); // Set your desired H1 font size
  if (props.uppercase) customStyles.push({ textTransform: 'uppercase' });
  if (props.lineOver) customStyles.push({ textDecorationLine: 'line-through' });

  customStyles.push(props.style);

  return (
    <Text numberOfLines={props.numberOfLines} style={customStyles}>
      {props.children}
    </Text>
  );
};

export default TextDefault;
