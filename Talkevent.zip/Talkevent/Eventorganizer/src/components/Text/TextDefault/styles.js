import { StyleSheet } from 'react-native'

const color = textColor =>
  StyleSheet.create({
    color: {
      color: textColor
    }
  })

export default color
import React from 'react';
import { Text, StyleSheet } from 'react-native';
import color from './color'; // Import your 'color' utility
import colors from '../../utilities/colors';

const TextDefault = (props) => {
  const textColor = props.textColor ? props.textColor : colors.fontMainColor;
  const textStyles = StyleSheet.flatten([
    color(textColor).color, // Use the 'color' utility here
    // ... other styles
  ]);
  
  // Rest of the component
}
