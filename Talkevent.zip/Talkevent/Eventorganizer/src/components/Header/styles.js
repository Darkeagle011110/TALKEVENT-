import { StyleSheet } from 'react-native';
import { alignment } from '../../../utilities/alignment';
import colors from '../../../utilities/colors'; // Import colors from your app's color palette

const styles = StyleSheet.create({
  leftIconPadding: {
    ...alignment.PLsmall,
    ...alignment.PRlarge,
    color: colors.primaryColor, // Customize the icon color based on your app's color palette
  },
});

export default styles;
