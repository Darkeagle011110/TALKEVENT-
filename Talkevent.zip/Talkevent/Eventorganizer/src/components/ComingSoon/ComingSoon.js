import React from 'react';
import { StyleSheet, View } from 'react-native';
import TextDefault from '../Text/TextDefault/TextDefault';
import colors from '../../utilities/colors'; // Import colors from your app's color palette

const ComingSoon = () => {
  return (
    <View style={styles.container}>
      <TextDefault center bold H5 textColor={colors.primaryColor}>
        Event feature coming soon
      </TextDefault>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});

export default ComingSoon;
