import { showMessage } from 'react-native-flash-message';
import PropTypes from 'prop-types';

export const EventFlashMessage = (props) => {
  showMessage({
    backgroundColor: 'rgba(52, 52, 52, .9)', // Customize background color as needed
    message: props.message,
    position: 'center',
    style: { borderRadius: 40 }, // Customize message box style
  });
};

EventFlashMessage.propTypes = {
  message: PropTypes.string.isRequired,
};
