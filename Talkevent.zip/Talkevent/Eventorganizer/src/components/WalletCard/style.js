import React from 'react';
import { View } from 'react-native';
import { StyleSheet, Dimensions } from 'react-native';
import colors from '../../utilities/colors';
import { alignment } from '../../utilities/alignment';

const { width } = Dimensions.get('window');

const EventRequestCard = ({ item }) => {
  return (
    <View style={[styles.container, styles.bgWhite]}>
      <TextDefault bold H4 textColor={colors.black}>
        {'Request ID:'}{' '}
        <TextDefault bolder H4 textColor={colors.primary}>
          {item?.requestId}
        </TextDefault>{' '}
      </TextDefault>
      <View style={styles.horizontalLine} />
      <RequestRow label={'Organizer Name'} value={item?.organizerName} color={colors.black} />
      <RequestRow label={'Event Title'} value={item?.eventTitle} color={colors.black} />
      <RequestRow
        label={'Request Amount'}
        value={`$${item?.requestAmount.toFixed(2)}`}
        color={colors.black}
      />
      <RequestRow
        label={'Request Time'}
        value={new Date(item?.requestTime).toDateString()}
        color={colors.black}
      />
      <RequestRow
        label={'Status'}
        value={item?.status}
        color={STATUS_COLORS[item?.status]}
      />
    </View>
  );
};

export const RequestRow = ({ label, value, color = colors.black }) => {
  return (
    <View style={styles.requestDetails}>
      <TextDefault style={styles.col1} textColor={colors.fontSecondColor} bolder>
        {label}
      </TextDefault>
      <TextDefault style={styles.col2} textColor={color} bold>
        {value}
      </TextDefault>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: width * 0.85,
    borderRadius: 20,
    alignItems: 'center',
    alignSelf: 'center',
    shadowColor: colors.fontSecondColor,
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.34,
    shadowRadius: 6.27,
    elevation: 10,
    ...alignment.PTsmall,
    ...alignment.PBsmall,
    ...alignment.PLlarge,
    ...alignment.PRlarge,
    ...alignment.MBmedium,
  },
  bgBlack: {
    backgroundColor: colors.black,
  },
  bgWhite: {
    backgroundColor: colors.white,
  },
  horizontalLine: {
    width: width * 0.75,
    borderBottomWidth: 1,
    borderBottomColor: colors.white,
    ...alignment.Msmall,
  },
  requestDetails: {
    display: 'flex',
    flexDirection: 'row',
    ...alignment.PBxSmall,
  },
  col1: {
    flex: 5,
  },
  col2: {
    flex: 5,
  },
});

export default EventRequestCard;
