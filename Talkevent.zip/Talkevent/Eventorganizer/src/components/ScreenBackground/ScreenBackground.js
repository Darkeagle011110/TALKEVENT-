import React from 'react';
import { View, StatusBar, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import styles from './style'; // Make sure to import the appropriate styles and assets

const EventBackground = ({ children }) => {
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        backgroundColor={styles.statusBarColor.backgroundColor} // Adjust as needed
        barStyle="dark-content"
      />
      <View style={styles.background}>
        <Image
          source={EventImage} // Replace with your event-related image asset
          style={styles.image}
          height={150} // Adjust height as needed
          width={250} // Adjust width as needed
        />
        {children}
      </View>
    </SafeAreaView>
  );
};

export default EventBackground;
