import React from 'react';
import { View, StatusBar, Image, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import styles from './style'; // Import your own styles
import EventBg from '../../assets/svg/EventBg.png'; // Replace with the relevant image asset
import { Ionicons } from '@expo/vector-icons';
import colors from '../../utilities/colors'; // Import your color definitions
import { useNavigation } from '@react-navigation/native';

const { height } = Dimensions.get('window');

const EventScreenBg = ({ children, backBtn = false }) => {
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.flex, styles.bgColor, { paddingTop: insets.top }]}>
      <StatusBar
        backgroundColor={styles.bgColor.backgroundColor}
        barStyle="dark-content"
      />
      <View style={styles.container}>
        {backBtn && (
          <View style={styles.icon}>
            <Ionicons
              onPress={() => navigation.goBack()}
              name="chevron-back"
              size={24}
              color={colors.white}
            />
          </View>
        )}
        <Image
          source={EventBg}
          style={styles.eventImage}
          height={height / 3}
          width={250}
        />
        <View style={styles.innerContainer}>{children}</View>
      </View>
    </View>
  );
};

export default EventScreenBg;
