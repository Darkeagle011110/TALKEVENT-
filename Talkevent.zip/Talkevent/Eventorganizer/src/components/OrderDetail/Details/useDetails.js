import { useContext, useState, useEffect } from 'react';
import UserContext from '../../../context/user';
import { gql, useQuery, useMutation, useSubscription } from '@apollo/client';
import { configuration, eventDetails } from '../../../apollo/queries';
import { bookEvent, cancelEventBooking } from '../../../apollo/mutations';
import { TabsContext } from '../../../context/tabs';
import { FlashMessage } from '../../FlashMessage/FlashMessage';
import { subscriptionEvent } from '../../../apollo/subscriptions';

const CONFIGURATION = gql`
  ${configuration}
`;

const BOOK_EVENT = gql`
  ${bookEvent}
`;

const EVENT_DETAILS = gql`
  ${eventDetails}
`;

const CANCEL_EVENT_BOOKING = gql`
  ${cancelEventBooking}
`;

const useDetails = eventData => {
  const { active, setActive } = useContext(TabsContext);
  const { bookedEvents, loadingBookedEvents } = useContext(UserContext);
  const [event, setEvent] = useState(eventData);

  useEffect(() => {
    if (!loadingBookedEvents && event) {
      setEvent(bookedEvents.find(e => e._id === event?._id));
    }
  }, [bookedEvents, event]);

  const eventTime = {
    hours: new Date(event?.eventTime).getHours(),
    minutes: new Date(event?.eventTime).getMinutes(),
    seconds: new Date(event?.eventTime).getSeconds(),
  };

  const currentTime = {
    hours: new Date().getHours(),
    minutes: new Date().getMinutes(),
    seconds: new Date().getSeconds(),
  };

  const eventSeconds =
    eventTime.hours * 3600 + eventTime.minutes * 60 + eventTime.seconds;
  const currentSeconds =
    currentTime.hours * 3600 + currentTime.minutes * 60 + currentTime.seconds;

  useSubscription(
    gql`
      ${subscriptionEvent}
    `,
    { variables: { id: event?._id }, skip: !event }
  );

  const {
    data: dataConfig,
    loading: loadingConfig,
    error: errorConfig,
  } = useQuery(CONFIGURATION);

  const [mutateBookEvent, { loading: loadingBookEvent }] = useMutation(
    BOOK_EVENT,
    {
      onCompleted,
      onError,
      update,
    }
  );

  const [mutateCancelEventBooking, { loading: loadingCancelEventBooking }] =
    useMutation(CANCEL_EVENT_BOOKING, {
      onCompleted,
      onError,
      update,
    });

  async function onCompleted(result) {
    if (result.cancelEventBooking) {
      FlashMessage({
        message: 'Event booking canceled successfully',
      });
      setActive('AvailableEvents');
    } else if (result.bookEvent) {
      FlashMessage({
        message: 'Event booked successfully',
      });
      setActive('MyBookings');
    }
  }

  function onError({ graphQLErrors, networkError }) {
    let message = 'Unknown error occurred';
    if (networkError) message = 'Internal Server Error';
    if (graphQLErrors) message = graphQLErrors.map(error => error.message).join(', ');

    FlashMessage({ message });
  }

  async function update(cache, { data: result }) {
    if (result.cancelEventBooking) {
      const data = cache.readQuery({ query: BOOKED_EVENTS });
      if (data) {
        const updatedEvents = data.bookedEvents.filter(
          e => e._id !== result.cancelEventBooking._id
        );
        cache.writeQuery({ query: BOOKED_EVENTS, data: { bookedEvents: updatedEvents } });
      }
    }
    if (result.bookEvent) {
      const data = cache.readQuery({ query: AVAILABLE_EVENTS });
      if (data) {
        const updatedEvents = data.availableEvents.filter(
          e => e._id !== result.bookEvent._id
        );
        cache.writeQuery({ query: AVAILABLE_EVENTS, data: { availableEvents: updatedEvents } });
      }
    }
  }

  return {
    active,
    event,
    dataConfig,
    currentSeconds,
    eventSeconds,
    loadingConfig,
    errorConfig,
    mutateBookEvent,
    mutateCancelEventBooking,
    loadingBookEvent,
    loadingCancelEventBooking,
  };
};

export default useDetails;
