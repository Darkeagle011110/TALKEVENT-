import { Image, View } from 'react-native';
import React, { useContext, useState, useEffect } from 'react';
import styles from './style';
import colors from '../../../utilities/colors';
import TextDefault from '../../Text/TextDefault/TextDefault';
import EventIcon from '../../../assets/svg/event-icon.png'; // Replace with your event-related icon

const STATUS_MESSAGES = {
  ACCEPTED: { text: 'Event Accepted', subText: 'You have accepted this event.' },
  PICKED: { text: 'Event Picked Up', subText: 'You have picked up this event.' },
  DELIVERED: { text: 'Event Delivered', subText: 'You have delivered this event.' },
  // Add more statuses as needed
};

const STATUS_ORDER = ['ACCEPTED', 'PICKED', 'DELIVERED'];

const formatTime = date =>
  new Date(date).toLocaleTimeString('en-US', { timeStyle: 'short' });

const Status = ({ event, itemId, pickedAt, deliveredAt, assignedAt }) => {
  // Replace this context and data fetching with your actual data structure
  const { bookedEvents, loadingBookedEvents } = useContext(UserContext);
  const [currentEvent, setCurrentEvent] = useState(event);

  useEffect(() => {
    if (!loadingBookedEvents) {
      setCurrentEvent(bookedEvents.find(e => e._id === itemId));
    }
  }, [bookedEvents]);

  if (!currentEvent) {
    return (
      <View style={styles.container}>
        <View style={styles.statusMessage}>
          <StatusMessage
            message={STATUS_MESSAGES.CANCELLED.text}
            subText={STATUS_MESSAGES.CANCELLED.subText}
          />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.statusMessage}>
        <Icon name={EventIcon} /> {/* Replace with your event-related icon */}
        <StatusMessage
          message={STATUS_MESSAGES[currentEvent.status].text}
          subText={STATUS_MESSAGES[currentEvent.status].subText}
        />
      </View>
      <View style={styles.status}>
        {STATUS_ORDER.map((status, index) => (
          <StatusRow
            key={status}
            status={status}
            time={
              (index === 0 && assignedAt) ||
              (index === 1 && pickedAt) ||
              (index === 2 && deliveredAt)
                ? formatTime(
                    index === 0
                      ? assignedAt
                      : index === 1
                      ? pickedAt
                      : deliveredAt
                  )
                : null
            }
            event={currentEvent}
          />
        ))}
      </View>
    </View>
  );
};

const StatusRow = ({ status, time, event }) => {
  const fillColor =
    STATUS_ORDER.indexOf(event.status) >= STATUS_ORDER.indexOf(status);
  return (
    <View style={styles.statusRow}>
      <View
        style={[
          styles.circle,
          fillColor ? styles.bgPrimary : styles.bgSecondary
        ]}
      />
      <View style={styles.statusOrder}>
        <TextDefault
          bolder
          H3
          textColor={fillColor ? colors.primary : colors.fontSecondColor}>
          {status}
        </TextDefault>
      </View>
      <View style={styles.time}>
        <TextDefault bolder H5 textColor={colors.fontSecondColor}>
          {time}
        </TextDefault>
      </View>
    </View>
  );
};

const StatusMessage = ({ message, subText }) => {
  return (
    <View style={styles.message}>
      <TextDefault bolder H3>
        {message}
      </TextDefault>
      <TextDefault bold H6 textColor={colors.fontSecondColor}>
        {subText}
      </TextDefault>
    </View>
  );
};

const Icon = ({ name }) => {
  return (
    <View style={styles.iconView}>
      <Image source={name} style={styles.icon} />
    </View>
  );
};

export default Status;
