export default {
  radio: {
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    // Add any event-specific styles here
  }
}
