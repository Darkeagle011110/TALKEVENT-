import React, { useContext, useState, useEffect } from 'react';
import { View, TouchableOpacity } from 'react-native';
import styles from './style';
import TextDefault from '../Text/TextDefault/TextDefault';
import colors from '../../utilities/colors';
import { TabsContext } from '../../context/tabs';
import UserContext from '../../context/user';

const EventBookingTabs = (props) => {
  const { active } = useContext(TabsContext);
  const { assignedEvents } = useContext(UserContext);

  const [eventsCount, setEventsCount] = useState(
    assignedEvents.filter((event) => event.status === 'active').length
  );

  useEffect(() => {
    setEventsCount(assignedEvents.filter((event) => event.status === 'active').length);
  }, [assignedEvents]);

  return (
    <View style={styles.container}>
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={() => props.navigation.navigate('Home')}
        style={[styles.row, active === 'UpcomingEvents' && styles.btn]}
      >
        <TextDefault
          bolder
          H5
          textColor={active === 'UpcomingEvents' ? colors.black : colors.white}
        >
          Upcoming Events
        </TextDefault>
      </TouchableOpacity>

      <TouchableOpacity
        activeOpacity={0.8}
        onPress={() => props.navigation.navigate('MyEvents')}
        style={[styles.row, active === 'MyEvents' && styles.btn]}
      >
        <TextDefault
          bolder
          H5
          textColor={active === 'MyEvents' ? colors.black : colors.white}
        >
          My Events
        </TextDefault>
        {active === 'UpcomingEvents' && (
          <View style={styles.rightBadge}>
            <TextDefault textColor={colors.black}>
              {eventsCount > 0 ? eventsCount : 0}
            </TextDefault>
          </View>
        )}
      </TouchableOpacity>
    </View>
  );
};

export default EventBookingTabs;
