import React from 'react';
import { View } from 'react-native';
import { useQuery, gql } from '@apollo/client';
import styles from './styles';
import TextDefault from '../../Text/TextDefault/TextDefault';
import Spinner from '../../Spinner/Spinner';
import TextError from '../../Text/TextError/TextError';
import colors from '../../../utilities/colors';

// Define your GraphQL query for the user's profile
const PROFILE = gql`
  query GetProfile {
    // Adjust this query to match your TALKEVENT application's schema
    user {
      id
      name
      // Add other user profile fields as needed
    }
  }
`;

function Profile() {
  // Use Apollo Client to fetch the user's profile
  const { data, loading, error } = useQuery(PROFILE);

  if (loading) {
    return <Spinner />;
  }

  if (error) {
    return <TextError text="Something went wrong. Try again later!" />;
  }

  // Extract user profile data from the Apollo Client query result
  const userProfile = data.user;

  return (
    <View style={styles.container}>
      <View style={styles.img}>
        <TextDefault textColor={colors.black} bold H2 center>
          {userProfile.name}
        </TextDefault>
      </View>
      <TextDefault center H3 textColor={colors.white}>
        Welcome
      </TextDefault>
    </View>
  );
}

export default Profile;
