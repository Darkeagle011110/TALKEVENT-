import { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../../context/auth';
import { gql, useMutation, useQuery } from '@apollo/client';
import UserContext from '../../context/user';
import { organizerProfile } from '../../apollo/queries';

const TOGGLE_ORGANIZER = gql`
  // Define your GraphQL mutation for toggling organizer availability
  // Make sure it matches your schema
`;

const useSidebar = () => {
  const { logout } = useContext(AuthContext);
  const { dataProfile } = useContext(UserContext);
  const [isEnabled, setIsEnabled] = useState(dataProfile?.organizer.available);

  const toggleSwitch = () => {
    // You will need to implement this mutation based on your schema
    // Pass the necessary variables for toggling organizer availability
    mutateToggle({ variables: { id: dataProfile.organizer._id }, onCompleted });
    setIsEnabled((previousState) => !previousState);
  };

  useEffect(() => {
    if (!dataProfile) return;
    setIsEnabled(dataProfile?.organizer.available);
  }, [dataProfile]);

  function onCompleted({ toggleAvailability }) {
    if (toggleAvailability) {
      setIsEnabled(toggleAvailability.available);
    }
  }

  // You will need to define the correct query based on your schema
  const { data: profileData } = useQuery(ORGANIZER_PROFILE, {
    variables: { organizerId: dataProfile.organizer._id },
  });

  const [mutateToggle] = useMutation(TOGGLE_ORGANIZER, {
    refetchQueries: [{ query: ORGANIZER_PROFILE, variables: { organizerId: dataProfile.organizer._id } }],
  });

  const datas = [
    // Add relevant links or items for your event organizer app
    {
      title: 'Product Page',
      icon: 'product-hunt',
      // Define the URL for the product page in your app
      navigateTo: 'YOUR_PRODUCT_PAGE_URL',
    },
    {
      title: 'Privacy Policy',
      icon: 'lock',
      // Define the URL for the privacy policy in your app
      navigateTo: 'YOUR_PRIVACY_POLICY_URL',
    },
    {
      title: 'About Us',
      icon: 'info-circle',
      // Define the URL for the about us page in your app
      navigateTo: 'YOUR_ABOUT_US_URL',
    },
  ];

  return {
    logout,
    isEnabled,
    toggleSwitch,
    datas,
    dataProfile,
  };
};

export default useSidebar;
