import React from 'react';
import { TouchableOpacity, View } from 'react-native';
import styles from './styles'; // Update the import path
import TextDefault from '../../Text/TextDefault/TextDefault'; // Update the import path
import { FontAwesome } from '@expo/vector-icons';
import { scale } from '../../../utilities/scaling'; // Update the import path
import colors from '../../../utilities/colors'; // Update the import path
import PropTypes from 'prop-types';

const NavItem = (props) => (
  <View style={styles.flex}>
    <TouchableOpacity style={styles.container} onPress={props.onPress}>
      <View style={styles.leftContainer}>
        <FontAwesome name={props.icon} size={scale(20)} color={colors.white} />
      </View>
      <View style={styles.rightContainer}>
        <TextDefault textColor={colors.white} H5 bold>
          {props.title}
        </TextDefault>
      </View>
    </TouchableOpacity>
  </View>
);

NavItem.propTypes = {
  onPress: PropTypes.func,
  icon: PropTypes.string, // Change 'icons' to 'icon'
  title: PropTypes.string.isRequired,
};

export default NavItem;
