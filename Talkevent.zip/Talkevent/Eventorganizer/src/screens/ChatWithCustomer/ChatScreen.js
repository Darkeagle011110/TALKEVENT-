import React from 'react';
import { View } from 'react-native'; // You can replace this with your preferred component library
import { GiftedChat, Bubble, Send } from 'react-native-gifted-chat';
import { useChatScreen } from './useChatScreen'; // Make sure to have your custom hook in place
import TextDefault from '../../components/Text/TextDefault/TextDefault'; // Replace with your text component
import styles from './styles'; // Update styles according to your app's design
import colors from '../../utilities/colors'; // Define your color scheme

const ChatScreen = () => {
  // Your custom logic for handling messages, input, and other functionality

  const renderSend = props => {
    return (
      <Send {...props} sendButtonProps={{ ...props, onPress: onSend }}>
        <View>
          {/* Customize your send button icon */}
        </View>
      </Send>
    );
  }

  const renderChatEmpty = props => {
    return (
      <View>
        <TextDefault
          style={styles.emptyChat}
          textColor={colors.fontSecondColor}
          H3>
          {/* Customize the empty chat message */}
        </TextDefault>
      </View>
    );
  }

  const renderBubble = props => {
    return (
      <Bubble
        {...props}
        textStyle={{
          right: {
            color: colors.white
          },
          left: {
            color: colors.black
          }
        }}
        wrapperStyle={{
          right: styles.bubbleRight,
          left: styles.bubbleLeft
        }}
        usernameStyle={{ color: colors.fontSecondColor }}
      />
    );
  }

  const scrollToBottomComponent = () => {
    return (
      /* Customize your scroll-to-bottom component */
    );
  }

  return (
    <GiftedChat
      messages={messages}
      user={{
        _id: profile.rider._id // Make sure to replace with the correct user data
      }}
      renderBubble={renderBubble}
      renderSend={renderSend}
      scrollToBottom
      scrollToBottomComponent={scrollToBottomComponent}
      renderAvatar={null}
      renderUsernameOnMessage
      renderChatEmpty={renderChatEmpty}
      inverted={Platform.OS !== 'web' || messages.length === 0}
      timeTextStyle={{
        left: { color: colors.fontMainColor },
        right: { color: colors.horizontalLine }
      }}
      placeholder="Message"
      textInputStyle={{ paddingTop: 10 }}
      text={inputMessage}
      onInputTextChanged={m => setInputMessage(m)}
    />
  );
}

export default ChatScreen;
