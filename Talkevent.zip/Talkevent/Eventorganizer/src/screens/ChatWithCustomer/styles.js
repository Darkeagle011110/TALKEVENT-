import { StyleSheet } from 'react-native';
import colors from '../../utilities/colors';

export default StyleSheet.create({
  rowDisplay: {
    display: 'flex',
    flexDirection: 'row',
  },
  accessoryContainer: {
    height: 100, // Adjust the height as needed
    paddingLeft: 20,
    display: 'flex',
    flexDirection: 'row',
  },
  accessoryImg: {
    height: 40, // Customize the image dimensions
    width: 40,
    borderRadius: 5,
  },
  accessoryIcon: {
    marginLeft: -10,
    marginTop: -10,
    position: 'relative',
    elevation: 999,
  },
  sendIcon: {
    marginBottom: 7, // Adjust the margin as needed
    marginRight: 10, // Adjust the margin as needed
  },
  emptyChat: {
    marginTop: '160%', // Adjust the positioning as needed
    transform: [{ scaleY: -1 }], // Depending on your UI layout
    marginLeft: '17%', // Adjust the positioning as needed
  },
  bubbleRight: {
    backgroundColor: colors.black,
    padding: 5, // Adjust the padding as needed
    marginBottom: 5,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 0,
  },
  bubbleLeft: {
    backgroundColor: colors.primary,
    padding: 5, // Adjust the padding as needed
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 15,
  },
});
