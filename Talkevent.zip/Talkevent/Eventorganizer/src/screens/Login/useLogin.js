import { useContext, useState } from 'react';
import { Dimensions } from 'react-native';
import { AuthContext } from '../../context/auth';
import { FlashMessage } from '../../components/FlashMessage/FlashMessage';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { gql, useMutation } from '@apollo/client';

const RIDER_LOGIN = gql`
  // Your riderLogin GraphQL query here
`;

const useLogin = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(true);
  const [usernameError, setUsernameError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const { height } = Dimensions.get('window');

  const { setTokenAsync } = useContext(AuthContext);

  const [mutate, { loading }] = useMutation(RIDER_LOGIN, {
    onCompleted,
    onError,
  });

  function validateForm() {
    let result = true;
    setUsernameError('');
    setPasswordError('');

    if (!username) {
      setUsernameError('Username is required!');
      result = false;
    }
    if (!password) {
      setPasswordError('Password is required!');
      result = false;
    }
    return result;
  }

  async function onCompleted(data) {
    FlashMessage({ message: 'Logged in' });
    await AsyncStorage.setItem('rider-id', data.riderLogin.userId);
    await setTokenAsync(data.riderLogin.token);
    // You may want to navigate to the next screen upon successful login.
    // You can add the navigation logic here.
  }

  function onError(error) {
    console.log('error', JSON.stringify(error));
    let message = 'Check internet connection';
    try {
      message = error.message;
    } catch (error) {}
    FlashMessage({ message: message });
  }

  async function onSubmit() {
    if (validateForm()) {
      // Implement the logic to submit the login request here
      // You can use the 'mutate' function to send the request to your GraphQL server.
      // Ensure you pass the required variables like 'username', 'password', and 'notificationToken'.
      // The 'onCompleted' and 'onError' functions will handle the response.
    }
  }

  return {
    username,
    setUsername,
    password,
    setPassword,
    usernameError,
    passwordError,
    onSubmit,
    showPassword,
    setShowPassword,
    loading,
    height,
  };
};

export default useLogin;
