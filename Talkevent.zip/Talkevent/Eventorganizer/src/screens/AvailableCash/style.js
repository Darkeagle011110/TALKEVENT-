import { StyleSheet, Dimensions } from 'react-native';

const { height } = Dimensions.get('window');

export default StyleSheet.create({
  transactionHistory: {
    height: height * 0.4, // Adjust the height as needed for your "TalkEvent" application
    // Add any additional styles specific to your application
  },
});
