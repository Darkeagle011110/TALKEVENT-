import { FlatList, View } from 'react-native';
import React, { useContext } from 'react';
import WalletScreenBg from '../../components/ScreenBackground/WalletScreenBg'; // Import your "TalkEvent" specific components
import Amount from '../../components/Amount/Amount'; // Import your "TalkEvent" specific components
import WalletCard from '../../components/WalletCard/WalletCard'; // Import your "TalkEvent" specific components
import styles from './style'; // Import your "TalkEvent" specific styles
import { riderEarnings } from '../../apollo/queries'; // Replace with your queries
import { gql, useQuery } from '@apollo/client'; // Replace with your Apollo Client setup
import Spinner from '../../components/Spinner/Spinner'; // Import your "TalkEvent" specific components
import TextDefault from '../../components/Text/TextDefault/TextDefault'; // Import your "TalkEvent" specific components
import colors from '../../utilities/colors'; // Import your color definitions
import UserContext from '../../context/user'; // Import your "TalkEvent" specific context

const AVAILABLE_CASH = gql`
  ${riderEarnings}
`;

const AvailableCash = () => {
  // Use your "TalkEvent" context here
  const { loadingProfile, errorProfile, dataProfile } = useContext(UserContext);

  // Replace with your "TalkEvent" specific Apollo Client setup
  const { loading, error, data, refetch, networkStatus, fetchMore } = useQuery(
    AVAILABLE_CASH,
    {
      variables: { offset: 0 },
      fetchPolicy: 'network-only',
      pollInterval: 60000,
    }
  );

  if (loadingProfile) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Spinner />
      </View>
    );
  }

  if (errorProfile) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <TextDefault>
          An error occurred while fetching rider information
        </TextDefault>
      </View>
    );
  }

  return (
    <WalletScreenBg backBtn>
      {loading ? (
        <Spinner />
      ) : error ? (
        <TextDefault center H5 textColor={colors.fontSecondColor}>
          An error occurred!
        </TextDefault>
      ) : (
        <FlatList
          onRefresh={refetch}
          refreshing={networkStatus !== 7}
          style={styles.transactionHistory}
          ListHeaderComponent={
            <Amount
              text="Total Amount"
              amount={dataProfile.rider.totalWalletAmount}
            />
          }
          data={data.riderEarnings}
          renderItem={({ item }) => <WalletCard item={item} />}
          keyExtractor={item => item.orderId}
          showsVerticalScrollIndicator={false}
          onEndReached={() =>
            fetchMore({ variables: { offset: data.riderEarnings.length } })
          }
        />
      )}
    </WalletScreenBg>
  );
};

export default AvailableCash;
