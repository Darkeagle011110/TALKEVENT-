import { Dimensions } from 'react-native';
import { useContext, useState, useEffect } from 'react';
import { gql, useMutation } from '@apollo/client';
import UserContext from '../../context/user';

const WITHDRAW_REQUEST = gql`
  mutation CreateWithdrawRequest($amount: Float!) {
    createWithdrawRequest(amount: $amount) {
      // Define the expected response fields here
      // You may need to modify this according to your GraphQL schema
    }
  }
`;

export const useWithdrawRequest = () => {
  const [error, setError] = useState('');
  const [amount, setAmount] = useState(0);
  const [requestSent, setRequestSent] = useState(false);
  const { dataProfile } = useContext(UserContext);

  const [mutate, { loading, error: withdrawRequestError }] = useMutation(
    WITHDRAW_REQUEST,
    {
      onCompleted,
      onError,
    }
  );

  useEffect(() => {
    if (withdrawRequestError) {
      setError(withdrawRequestError.message);
    }
  }, [withdrawRequestError]);

  function validateForm() {
    setError('');

    if (!amount) {
      setError('Amount is required!');
      return false;
    } else if (amount < MIN_WITHDRAW_AMOUNT) {
      setError(`Amount must be greater than ${MIN_WITHDRAW_AMOUNT}!`);
      return false;
    } else if (amount > dataProfile.rider.currentWalletAmount) {
      setError('Withdraw amount must be less than or equal to wallet amount!');
      return false;
    }
    return true;
  }

  function onCompleted(data) {
    // Handle the completed mutation response if needed
    setRequestSent(true);
  }

  function onError(error) {
    // Handle the error if needed
    console.log('Error:', error);
  }

  function onSubmit() {
    if (validateForm()) {
      mutate({
        variables: {
          amount: parseFloat(amount),
        },
      });
    }
  }

  return {
    dataProfile,
    error,
    amount,
    setAmount,
    requestSent,
    loading,
    onSubmit,
  };
};
