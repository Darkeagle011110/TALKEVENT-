import React, { useLayoutEffect } from 'react';
import { View, TouchableOpacity } from 'react-native';
import { useSafeArea } from 'react-native-safe-area-context';
import styles from './styles';
import i18n from '../../../i18n';
import TextDefault from '../../components/Text/TextDefault/TextDefault';
import colors from '../../utilities/colors';
import { useNavigation } from '@react-navigation/native';

const helpLinks = [
  {
    title: 'FAQ',
    url: '/faq', // Define the URL for the FAQ page in your app
  },
  {
    title: 'Contact Support',
    url: '/contact-support', // Define the URL for the contact support page in your app
  },
  {
    title: 'User Guide',
    url: '/user-guide', // Define the URL for the user guide in your app
  },
  {
    title: 'Terms of Service',
    url: '/terms-of-service', // Define the URL for the terms of service page in your app
  },
];

function EventHelp() {
  const navigation = useNavigation();
  const inset = useSafeArea();

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: null,
      headerTitle: i18n.t('titleHelp'), // Adjust the title as needed
    });
  }, [navigation]);

  return (
    <>
      <View style={styles.flex}>
        {helpLinks.map(({ title, url }, index) => (
          <TouchableOpacity
            onPress={() => navigation.navigate('HelpBrowser', { title, url })}
            style={styles.itemContainer}
            key={index}>
            <TextDefault textColor={colors.fontMainColor} H4>
              {title}
            </TextDefault>
          </TouchableOpacity>
        ))}
      </View>
      <View
        style={{
          paddingBottom: inset.bottom,
          backgroundColor: colors.themeBackground,
        }}
      />
    </>
  );
}

export default EventHelp;
