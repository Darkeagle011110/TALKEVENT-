import { ScrollView, View, Image } from 'react-native'
import React from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'
import { Ionicons } from '@expo/vector-icons'
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps'
import MapViewDirections from 'react-native-maps-directions'
import styles from './styles'
import colors from '../../utilities/colors'
import useOrderDetail from './useOrderDetail'

const OrderDetail = () => {
  const {
    locationPin,
    eventVenuePin,
    destinationAddressPin,
    GOOGLE_MAPS_KEY,
    distance,
    setDistance,
    duration,
    setDuration,
    order,
    route,
    navigation,
    orderID
  } = useOrderDetail()

  return (
    <SafeAreaView>
      <ScrollView showsVerticalScrollIndicator={false} style={styles.container}>
        <View style={styles.mapView}>
          {locationPin && (
            <MapView
              style={styles.map}
              showsUserLocation
              zoomEnabled={true}
              zoomControlEnabled={true}
              rotateEnabled={false}
              initialRegion={{
                latitude: locationPin.location.latitude,
                longitude: locationPin.location.longitude,
                latitudeDelta: 0.0922,
                longitudeDelta: 0.0421
              }}
              provider={PROVIDER_GOOGLE}>
              {destinationAddressPin && (
                <Marker
                  coordinate={destinationAddressPin.location}
                  title="Destination Address"
                  // Handle navigation to the destination address here
                >
                  <Image source={/* Your destination icon image */} style={{ height: 35, width: 32 }} />
                </Marker>
              )}
              {eventVenuePin && (
                <Marker
                  coordinate={eventVenuePin.location}
                  title="Event Venue"
                  // Handle navigation to the event venue here
                >
                  <Image source={/* Your event venue icon image */} style={{ height: 35, width: 32 }} />
                </Marker>
              )}
              {locationPin && (
                <Marker
                  coordinate={locationPin.location}
                  title="Event Organizer"
                  // Handle navigation to the event organizer location here
                >
                  <Image source={/* Your event organizer icon image */} style={{ height: 35, width: 32 }} />
                </Marker>
              )}
              {order?.orderStatus === 'ACCEPTED' ? (
                <MapViewDirections
                  origin={locationPin.location}
                  destination={eventVenuePin.location}
                  apikey={GOOGLE_MAPS_KEY}
                  strokeWidth={4}
                  strokeColor={colors.black}
                  onReady={result => {
                    setDistance(result.distance)
                    setDuration(result.duration)
                  }}
                />
              ) : order?.orderStatus === 'PICKED' ? (
                <MapViewDirections
                  origin={locationPin.location}
                  destination={destinationAddressPin.location}
                  apikey={GOOGLE_MAPS_KEY}
                  strokeWidth={4}
                  strokeColor={colors.black}
                  onReady={result => {
                    setDistance(result.distance)
                    setDuration(result.duration)
                  }}
                />
              ) : (
                <MapViewDirections
                  origin={eventVenuePin.location}
                  destination={destinationAddressPin.location}
                  apikey={GOOGLE_MAPS_KEY}
                  strokeWidth={4}
                  strokeColor={colors.black}
                  onReady={result => {
                    setDistance(result.distance)
                    setDuration(result.duration)
                  }}
                />
              )}
            </MapView>
          )}
        </View>
        <View style={styles.iconView}>
          <Ionicons
            onPress={() => navigation.goBack()}
            name="chevron-back"
            size={26}
            color={colors.white}
            style={styles.icon}
          />
        </View>
        {/* Rest of the OrderDetail component remains the same */}
      </ScrollView>
    </SafeAreaView>
  )
}

export default OrderDetail
