import React, { useLayoutEffect, useState, useContext, useEffect } from 'react'
import { useNavigation, useRoute } from '@react-navigation/native'
import { Ionicons } from '@expo/vector-icons'
import EventContext from '../../context/event'  // Replace with the appropriate context for events
import getEnvVars from '../../../environment'
import { useLocationContext } from '../../context/location'

const useOrderDetail = () => {
  const navigation = useNavigation()
  const route = useRoute()
  const [orderID] = useState(route.params?.itemId)
  const { eventOrders, loadingEventOrders } = useContext(EventContext)  // Replace with the context for event orders
  const [order, setOrder] = useState(route.params?.order)
  const { GOOGLE_MAPS_KEY } = getEnvVars()
  const { location } = useLocationContext()

  const [distance, setDistance] = useState(null)
  const [duration, setDuration] = useState(null)

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: null,
      headerTitle: null,
      headerLeft: () => (
        <Ionicons
          onPress={() => navigation.navigate('Home')}  // Adjust the navigation route
          name="chevron-back"
          size={24}
          color="black"
        />
      )
    })
  }, [navigation])

  useEffect(() => {
    if (!loadingEventOrders) {
      setOrder(eventOrders.find(o => o._id === orderID))
    }
  }, [loadingEventOrders, eventOrders])

  // Define the pins or location information specific to event organizers
  const eventLocationPin = {
    label: 'Event Location',  // Customize the label
    location: {
      latitude: +event.location.coordinates[1] || 0,  // Adjust the location data for the event
      longitude: +event.location.coordinates[0] || 0
    }
  }

  // Define any other location pins as needed

  return {
    eventLocationPin,  // Replace with appropriate location pins
    GOOGLE_MAPS_KEY,
    distance,
    setDistance,
    duration,
    setDuration,
    loadingEventOrders,
    route,
    navigation,
    orderID,
    order
  }
}

export default useOrderDetail
