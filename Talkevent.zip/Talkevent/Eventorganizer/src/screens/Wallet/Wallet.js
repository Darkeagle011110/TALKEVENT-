import React, { useContext } from 'react'
import { TouchableOpacity, View } from 'react-native'
import WalletScreenBg from '../../components/ScreenBackground/WalletScreenBg'
import styles from './style'
import Amount from '../../components/Amount/Amount'
import TextDefault from '../../components/Text/TextDefault/TextDefault'
import { useNavigation } from '@react-navigation/native'
import Spinner from '../../components/Spinner/Spinner'
import ConfigurationContext from '../../context/configuration'

const Wallet = () => {
  const navigation = useNavigation()
  const configuration = useContext(ConfigurationContext)

  // Simulate loading for demonstration purposes (replace with actual data loading)
  const loadingProfile = false
  const errorProfile = false
  const walletAmount = 500.0 // Replace with the actual wallet amount

  if (loadingProfile) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Spinner />
      </View>
    )
  }

  if (errorProfile) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <TextDefault bold H5>
          Error occurred while fetching wallet data
        </TextDefault>
      </View>
    )
  }

  return (
    <WalletScreenBg>
      <View style={{ flex: 1, justifyContent: 'space-between', paddingTop: 10 }}>
        <Amount
          text="Your Wallet"
          amount={walletAmount.toFixed(2)}
          shadow
          icon
          disabled={false}
          bg
        />
        <View style={styles.textView}>
          <TextDefault bold H5>
            Minimum withdrawal amount is{' '}
          </TextDefault>
          <TextDefault H4 bolder>
            {configuration.currencySymbol}50.00
          </TextDefault>
        </View>
        <View style={styles.btnView}>
          <TouchableOpacity
            onPress={() => navigation.navigate('Withdraw')}
            activeOpacity={0.8}
            style={[styles.btn, styles.withdrawBtn]}>
            <TextDefault bolder H5 center>
              Withdraw Funds
            </TextDefault>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => navigation.navigate('WalletHistory')}
            activeOpacity={0.8}
            style={[styles.btn, styles.historyBtn]}>
            <TextDefault bolder H5 center>
              Wallet History
            </TextDefault>
          </TouchableOpacity>
        </View>
      </View>
    </WalletScreenBg>
  )
}

export default Wallet
