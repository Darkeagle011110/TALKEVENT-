import { View, FlatList } from 'react-native'
import React, { useContext, useState, useEffect } from 'react'
import ScreenBackground from '../../components/ScreenBackground/ScreenBackground'
import styles from './style'
import EventTabs from '../../components/EventTabs/EventTabs' // Replace with your event-specific tabs component
import Event from '../../components/Event/Event' // Replace with your event-specific component
import { EventContext } from '../../context/event' // Replace with your event context
import Spinner from '../../components/Spinner/Spinner'
import TextError from '../../components/Text/TextError/TextError'
import LottieView from 'lottie-react-native'
import TextDefault from '../../components/Text/TextDefault/TextDefault'
import colors from '../../utilities/colors'

const Events = ({ navigation }) => {
  const { setActiveEvent } = useContext(EventContext) // Replace with your event context
  const {
    loadingEvents,
    errorEvents,
    eventList, // Replace with the data related to event list
    refetchEvents,
    networkStatusEvents
  } = useContext(EventContext) // Replace with your event context
  const [events, setEvents] = useState([])

  useEffect(() => {
    if (eventList) {
      setEvents(eventList) // Update to filter or process the event list as needed
    }
  }, [eventList])

  return (
    <ScreenBackground>
      <View style={styles.innerContainer}>
        <View>
          <EventTabs navigation={navigation} /> // Replace with your event-specific tabs
        </View>
        {loadingEvents ? (
          <View style={styles.margin500}>
            <Spinner />
          </View>
        ) : errorEvents ? (
          <View style={styles.margin500}>
            <TextError text="Something went wrong. Please try again later!" />
          </View>
        ) : events.length > 0 ? (
          <FlatList
            style={styles.eventsContainer}
            contentContainerStyle={{
              justifyContent: 'center',
              alignItems: 'center'
            }}
            keyExtractor={(item) => item._id} // Update this to match your event data structure
            data={events}
            showsVerticalScrollIndicator={false}
            refreshing={networkStatusEvents === 4}
            onRefresh={refetchEvents}
            renderItem={({ item }) => (
              <Event
                event={item} // Pass the event data as props to your event component
                key={item._id} // Update this based on your event data structure
              />
            )}
          />
        ) : (
          <View>
            <LottieView
              style={{
                width: '100%'
              }}
              source={require('../../assets/loader.json')}
              autoPlay
              loop
            />
            <TextDefault bolder center H3 textColor={colors.fontSecondColor}>
              You don't have any events yet!
            </TextDefault>
          </View>
        )}
      </View>
    </ScreenBackground>
  )
}

export default Events
