import React, { useCallback, useContext, useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import * as Notifications from 'expo-notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Login from '../screens/Login/Login';
import Sidebar from '../components/Sidebar/Sidebar';
import Events from '../screens/Events/Events';
import EventDetail from '../screens/EventDetail/EventDetail';
import Profile from '../screens/Profile/Profile';
import LocationPermissions from '../screens/LocationPermissions/LocationPermissions';
import { AuthContext } from '../context/auth';
import { SoundContextProvider } from '../context/sound';
import { gql, useApolloClient } from '@apollo/client';
import { eventList } from '../apollo/queries';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();

function MyTabs() {
  return (
    <Tab.Navigator
      initialRouteName="Events"
      screenOptions={({ route }) => tabIcon(route)}
      tabBarOptions={tabOptions()}>
      <Tab.Screen name="Events" component={Events} options={{ title: 'Events' }} />
      <Tab.Screen name="Profile" component={Profile} options={{ title: 'Profile' }} />
    </Tab.Navigator>
  );
}

function Auth() {
  return (
    <Stack.Navigator headerMode="none">
      <Stack.Screen name="Login" component={Login} />
    </Stack.Navigator>
  );
}

function LocationStack() {
  return (
    <Stack.Navigator
      initialRouteName="Location"
      screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Location" component={LocationPermissions} />
    </Stack.Navigator>
  );
}

function Main() {
  const { locationPermission } = useLocationContext();
  const client = useApolloClient();
  const lastNotificationResponse = Notifications.useLastNotificationResponse();
  const handleNotification = useCallback(
    async (response) => {
      // Handle event notifications, similar to your previous event handling logic
    },
    [lastNotificationResponse]
  );
  React.useEffect(() => {
    if (
      lastNotificationResponse &&
      lastNotificationResponse.notification.request.content.data.type === 'event' &&
      lastNotificationResponse.actionIdentifier === Notifications.DEFAULT_ACTION_IDENTIFIER
    ) {
      handleNotification(lastNotificationResponse);
    }
  }, [lastNotificationResponse]);

  useEffect(() => {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: false,
        shouldSetBadge: false,
      }),
    });
    const subscription = Notifications.addNotificationResponseReceivedListener();
    return () => subscription.remove();
  }, []);

  return locationPermission ? (
    <SoundContextProvider>
      <Drawer.Navigator
        drawerType="slide"
        drawerPosition="right"
        drawerContent={(props) => <Sidebar {...props} />}>
        <Drawer.Screen name="Events" component={NoDrawer} />
      </Drawer.Navigator>
    </SoundContextProvider>
  ) : (
    <LocationStack />
  );
}

function NoDrawer() {
  return (
    <Stack.Navigator initialRouteName="Events" screenOptions={screenOptions()}>
      <Stack.Screen name="Events" component={MyTabs} />
      <Stack.Screen name="EventDetail" component={EventDetail} />
      {/* Add other screens related to event details */}
    </Stack.Navigator>
  );
}

function AppContainer() {
  const { token } = useContext(AuthContext);
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        {token ? <Main /> : <Auth />}
      </NavigationContainer>
    </SafeAreaProvider>
  );
}

export default AppContainer;
