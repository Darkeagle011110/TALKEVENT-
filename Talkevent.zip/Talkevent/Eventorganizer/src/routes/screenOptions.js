import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRoute } from '@react-navigation/native';
import { Text } from 'react-native';
import colors from './utilities/colors';

const screenOptions = {
  headerShown: false, // You can customize this based on your screen requirements
};

const tabIcon = route => ({
  tabBarIcon: ({ color, size }) => {
    let iconName;
    if (route.name === 'Events') {
      iconName = 'ios-calendar'; // Replace with your event icon
    } else if (route.name === 'Tickets') {
      iconName = 'ios-pricetag'; // Replace with your ticket icon
    } else if (route.name === 'Profile') {
      iconName = 'ios-person'; // Replace with your profile icon
    }
    return (
      <View style={{ paddingTop: 10 }}>
        <Ionicons name={iconName} size={size} color={color} />
      </View>
    );
  },
});

const tabOptions = {
  activeTintColor: colors.primary, // Define your primary color
  inactiveTintColor: colors.gray, // Define your inactive color
  tabStyle: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  labelStyle: {
    fontSize: 12, // Customize the font size
    fontWeight: 'bold',
  },
  style: {
    backgroundColor: colors.white, // Customize the background color
  },
};

export { screenOptions, tabOptions, tabIcon };
