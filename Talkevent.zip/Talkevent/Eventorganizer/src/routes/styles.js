import { StyleSheet } from 'react-native';
import { scale } from './utilities/scaling'; // Make sure to import your scaling utility
import colors from './utilities/colors'; // Import your color definitions

const styles = StyleSheet.create({
  badge: {
    position: 'absolute',
    right: -scale(6), // Adjust the badge position as needed
    top: 0, // Adjust the badge position as needed
    borderRadius: scale(9),
    width: scale(18),
    height: scale(18),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.primary, // Set your badge background color
  },
});

export default styles;
