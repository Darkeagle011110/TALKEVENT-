let navObj = null;

function setGlobalNavigation(ref) {
  navObj = ref;
}

function navigateToEventDetail(eventId) {
  navObj.navigate('EventDetail', { eventId });
}

function navigateToProfile() {
  navObj.navigate('Profile');
}

function goBack() {
  navObj.goBack();
}

export default {
  setGlobalNavigation,
  navigateToEventDetail,
  navigateToProfile,
  goBack
};
