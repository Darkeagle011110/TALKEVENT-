import React, { useState, useEffect, useContext, useRef } from 'react';
import * as Location from 'expo-location';
import { LocationAccuracy } from 'expo-location';

const locationContext = React.createContext({
  locationPermission: false,
  setLocationPermission: () => {},
});

export const LocationProvider = ({ children }) => {
  const locationListener = useRef(null);
  const [locationPermission, setLocationPermission] = useState(false);
  const [location, setLocation] = useState(null);

  const getLocationPermission = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status === 'granted') {
      setLocationPermission(true);
    }
  };

  useEffect(() => {
    getLocationPermission();
  }, []);

  useEffect(() => {
    if (!locationPermission) return;
    const trackUserLocation = async () => {
      locationListener.current = await Location.watchPositionAsync(
        {
          accuracy: LocationAccuracy.BestForNavigation,
          distanceInterval: 100,
        },
        (newLocation) => {
          setLocation({
            latitude: newLocation.coords.latitude.toString(),
            longitude: newLocation.coords.longitude.toString(),
          });
        }
      );
    };

    trackUserLocation();

    return () => {
      locationListener.current && locationListener.current.remove();
    };
  }, [locationPermission]);

  return (
    <locationContext.Provider
      value={{ locationPermission, setLocationPermission, location }}>
      {children}
    </locationContext.Provider>
  );
};

export const LocationConsumer = locationContext.Consumer;

export const useLocationContext = () => useContext(locationContext);

export default locationContext;
