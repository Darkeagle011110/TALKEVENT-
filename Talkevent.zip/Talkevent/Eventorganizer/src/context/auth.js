import React, { createContext, useContext, useReducer } from 'react';

// Define initial state
const initialState = {
  user: null, // You can set the initial user state here
  isAuthenticated: false, // Set to true if the user is authenticated
};

// Define actions (these are just examples, modify them as per your authentication flow)
const AuthActions = {
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
};

// Create a reducer function to handle actions and update the state
function authReducer(state, action) {
  switch (action.type) {
    case AuthActions.LOGIN:
      // Handle the login action, update user and isAuthenticated accordingly
      return {
        ...state,
        user: action.payload, // You can set user data here
        isAuthenticated: true,
      };
    case AuthActions.LOGOUT:
      // Handle the logout action, reset user and isAuthenticated
      return {
        ...state,
        user: null,
        isAuthenticated: false,
      };
    default:
      return state;
  }
}

// Create the AuthContext
export const AuthContext = createContext();

// Create an AuthProvider component to wrap your app with the AuthContext
export function AuthProvider({ children }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  return (
    <AuthContext.Provider value={{ state, dispatch }}>
      {children}
    </AuthContext.Provider>
  );
}

// Create a custom hook to easily access the AuthContext and dispatch actions
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
