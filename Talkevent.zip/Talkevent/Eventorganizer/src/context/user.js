import React, { useContext, useEffect, useRef } from 'react';
import {
  useQuery,
  useMutation,
  gql,
  useApolloClient,
  subscribeToMore,
} from '@apollo/client';

// Define your GraphQL queries and subscriptions
const GET_USER_PROFILE = gql`
  // Your user profile query here
`;

const GET_ASSIGNED_EVENTS = gql`
  // Your assigned events query here
`;

const EVENT_ASSIGNMENT_SUBSCRIPTION = gql`
  // Your event assignment subscription here
`;

const UPDATE_USER_LOCATION_MUTATION = gql`
  // Your mutation for updating user location here
`;

const UserContext = React.createContext({});

export const UserProvider = (props) => {
  const client = useApolloClient();
  const locationListener = useRef(null);
  const { locationPermission } = useLocationContext(); // Assuming you have a LocationContext

  const {
    loading: loadingUserProfile,
    error: errorUserProfile,
    data: dataUserProfile,
  } = useQuery(GET_USER_PROFILE, {
    fetchPolicy: 'network-only',
    onCompleted,
    pollInterval: 10000,
    onError: error1,
  });

  const {
    client,
    loading: loadingAssignedEvents,
    error: errorAssignedEvents,
    data: dataAssignedEvents,
    networkStatus: networkStatusAssignedEvents,
    refetch: refetchAssignedEvents,
  } = useQuery(GET_ASSIGNED_EVENTS, {
    onCompleted,
    onError: error2,
    fetchPolicy: 'network-only',
    notifyOnNetworkStatusChange: true,
  });

  let unsubscribeEventAssignment = null;

  useEffect(() => {
    if (!dataUserProfile) return;

    // Subscribe to event assignment updates
    const { unsubscribe } = subscribeToEventAssignment();
    unsubscribeEventAssignment = unsubscribe;

    return () => {
      unsubscribeEventAssignment && unsubscribeEventAssignment();
    };
  }, [dataUserProfile]);

  useEffect(() => {
    if (locationPermission) {
      trackUserLocation();
    }
    return () => {
      locationListener.current && locationListener.current.remove();
    };
  }, [locationPermission]);

  function onCompleted(result) {
    console.log('User profile:', result);
  }

  function error1(error) {
    console.log('Error fetching user profile:', error);
  }

  function error2(error) {
    console.log('Error fetching assigned events:', error);
  }

  // You can use your GraphQL subscriptions for event assignment updates
  const subscribeToEventAssignment = () => {
    try {
      const unsubscribe = subscribeToMore({
        document: EVENT_ASSIGNMENT_SUBSCRIPTION,
        // Define your subscription variables here based on your application's needs
        variables: { userId: dataUserProfile.userId },
        updateQuery: (prev, { subscriptionData }) => {
          if (!subscriptionData.data) return prev;
          // Update the assigned events data based on subscription data
          // Modify this part based on your actual data structure
          return {
            assignedEvents: [
              ...prev.assignedEvents,
              subscriptionData.data.eventAssignment,
            ],
          };
        },
      });

      return { unsubscribe };
    } catch (error) {
      console.log('Error subscribing to event assignment:', error);
    }
  }

  // Define a function to update the user's location in your GraphQL server
  const updateUserLocation = (latitude, longitude) => {
    try {
      client.mutate({
        mutation: UPDATE_USER_LOCATION_MUTATION,
        variables: {
          userId: dataUserProfile.userId,
          latitude,
          longitude,
        },
      });
    } catch (error) {
      console.log('Error updating user location:', error);
    }
  }

  return (
    <UserContext.Provider
      value={{
        loadingUserProfile,
        errorUserProfile,
        dataUserProfile,
        loadingAssignedEvents,
        errorAssignedEvents,
        assignedEvents: loadingAssignedEvents || errorAssignedEvents
          ? []
          : dataAssignedEvents.assignedEvents,
        refetchAssignedEvents,
        networkStatusAssignedEvents,
        updateUserLocation,
      }}
    >
      {props.children}
    </UserContext.Provider>
  );
};

export const UserConsumer = UserContext.Consumer;
export const useUserContext = () => useContext(UserContext);
export default UserContext;
