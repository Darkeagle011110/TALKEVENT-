import React from 'react';
import { useQuery, gql } from '@apollo/client';

const GET_CONFIGURATION = gql`
  query GetConfiguration {
    configuration {
      // Define the configuration fields you need here
      // For example: title, logo, themeColor, etc.
    }
  }
`;

const ConfigurationContext = React.createContext({});

export const ConfigurationProvider = (props) => {
  const { loading, data, error } = useQuery(GET_CONFIGURATION);

  // Handle loading and error states, provide default values
  if (loading || error || !data.configuration) {
    // You can handle errors or loading here
    // For now, provide default values as an empty object
    const configuration = {};
    return (
      <ConfigurationContext.Provider value={configuration}>
        {props.children}
      </ConfigurationContext.Provider>
    );
  }

  // Extract configuration data from the query response
  const configuration = data.configuration;

  return (
    <ConfigurationContext.Provider value={configuration}>
      {props.children}
    </ConfigurationContext.Provider>
  );
};

export const ConfigurationConsumer = ConfigurationContext.Consumer;

export default ConfigurationContext;
