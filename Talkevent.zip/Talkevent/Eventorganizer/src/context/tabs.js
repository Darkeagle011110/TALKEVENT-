import React, { useState, useContext } from 'react';

const TabsContext = React.createContext();

export const TabsProvider = ({ children }) => {
  const [active, setActive] = useState('Home'); // Initialize with the default tab

  const switchTab = (newTab) => {
    setActive(newTab);
  };

  return (
    <TabsContext.Provider value={{ active, switchTab }}>
      {children}
    </TabsContext.Provider>
  );
};

export const useTabsContext = () => useContext(TabsContext);

export default TabsContext;
