import { Linking, Alert, Platform } from 'react-native';

export const callPhoneNumber = phone => {
  let phoneNumber = phone;
  if (Platform.OS === 'android') {
    phoneNumber = `tel:${phone}`;
  } else {
    phoneNumber = `telprompt:${phone}`;
  }

  Linking.openURL(phoneNumber)
    .catch(error => {
      Alert.alert('Unable to make the call. Please try again later.');
      console.error(error);
    });
};
