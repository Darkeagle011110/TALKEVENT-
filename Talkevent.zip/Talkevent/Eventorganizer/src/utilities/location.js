import * as TaskManager from 'expo-task-manager';
import { clientRef } from '../apollo/index';
import { updateLocation } from '../apollo/mutations';
import { gql } from '@apollo/client';

const UPDATE_LOCATION = gql`
  ${updateLocation}
`;

TaskManager.defineTask('EVENT_LOCATION', async ({ data: { locations }, error }) => {
  try {
    if (error) {
      return;
    }
    if (locations.length > 0) {
      const {
        coords: { latitude, longitude },
      } = locations[locations.length - 1];

      // You may need to adapt this part based on your TALKEVENT data model.
      // For example, you might want to update the event's location.
      await clientRef.mutate({
        mutation: UPDATE_LOCATION,
        variables: {
          eventLatitude: latitude.toString(),
          eventLongitude: longitude.toString(),
        },
      });
    }
  } catch (error) {
    console.log('Error updating event location:', error);
  }
});
