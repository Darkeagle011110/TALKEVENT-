export const fontStyles = {
  MuseoSans300: 'MuseoSans300',
  MuseoSans500: 'MuseoSans500',
  MuseoSans700: 'MuseoSans700'
}