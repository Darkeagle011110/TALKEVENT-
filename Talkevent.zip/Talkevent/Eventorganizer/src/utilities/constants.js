export const MAX_TIME = 120
export const MIN_WITHDRAW_AMOUNT = 10