import * as Updates from 'expo-updates';

const ENV = {
  development: {
    GRAPHQL_URL: 'https://talkevent-multivendor.up.railway.app/graphql',
    WS_GRAPHQL_URL: 'wss://talkevent-multivendor.up.railway.app/graphql',
    SENTRY_DSN: 'YOUR_SENTRY_DSN',
    GOOGLE_MAPS_KEY: 'YOUR_GOOGLE_MAPS_API_KEY',
  },
  staging: {
    GRAPHQL_URL: 'https://talkevent-multivendor.up.railway.app/graphql',
    WS_GRAPHQL_URL: 'wss://talkevent-multivendor.up.railway.app/graphql',
    SENTRY_DSN: 'YOUR_SENTRY_DSN',
    GOOGLE_MAPS_KEY: 'YOUR_GOOGLE_MAPS_API_KEY',
  },
  production: {
    GRAPHQL_URL: 'https://talkevent-multivendor.up.railway.app/graphql',
    WS_GRAPHQL_URL: 'wss://talkevent-multivendor.up.railway.app/graphql',
    SENTRY_DSN: 'YOUR_SENTRY_DSN',
    GOOGLE_MAPS_KEY: 'YOUR_GOOGLE_MAPS_API_KEY',
  },
};

const getEnvVars = (env = Updates.releaseChannel) => {
  if (env === 'production') {
    return ENV.production;
  } else if (env === 'staging') {
    return ENV.staging;
  } else {
    return ENV.development;
  }
};

export default getEnvVars;
