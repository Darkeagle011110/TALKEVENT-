import React, { useState, useEffect } from 'react';
import {
  ActivityIndicator,
  View,
  StatusBar,
  StyleSheet,
  LogBox,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Font from 'expo-font';
import { ApolloProvider } from '@apollo/client';
import FlashMessage from 'react-native-flash-message';
import * as Location from 'expo-location';
import * as SplashScreen from 'expo-splash-screen';
import * as Updates from 'expo-updates';
import * as Sentry from 'sentry-expo';
import AppContainer from './src/routes/index';
import i18n from './i18n'; // Your localization setup
import colors from './src/utilities/colors';
import setupApolloClient from './src/apollo/index';
import { ConfigurationProvider } from './src/context/configuration';
import { AuthContext } from './src/context/auth';
import { TabsContext } from './src/context/tabs';
import TextDefault from './src/components/Text/TextDefault/TextDefault';
import { LocationProvider } from './src/context/location';
import getEnvVars from './environment'; // Your environment setup
import moment from 'moment-timezone';

moment.tz.setDefault('YourTimeZone'); // Replace 'YourTimeZone' with the appropriate time zone

LogBox.ignoreLogs([
  'Warning: ...',
  'Sentry Logger ',
  'Constants.deviceYearClass',
]); // Ignore log notifications

LogBox.ignoreAllLogs(); // Ignore all log notifications

const client = setupApolloClient();
const { SENTRY_DSN } = getEnvVars();

Sentry.init({
  dsn: SENTRY_DSN,
  enableInExpoDevelopment: true,
  debug: true,
  tracesSampleRate: 1.0, // Change to 0.2 in production
});

export default function App() {
  const [appIsReady, setAppIsReady] = useState(false);
  const [token, setToken] = useState(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [active, setActive] = useState('YourInitialActiveTab'); // Set your initial active tab here

  useEffect(() => {
    ;(async () => {
      await SplashScreen.preventAutoHideAsync();
      await i18n.initAsync();
      await Font.loadAsync({
        // Load your fonts here
      });

      const token = await AsyncStorage.getItem('user-token'); // Change to your user token storage key
      if (token) setToken(token);
      setAppIsReady(true);
      await SplashScreen.hideAsync();
    })();
  }, []);

  useEffect(() => {
    // Check for app updates
    if (!__DEV__) {
      ;(async () => {
        const { isAvailable } = await Updates.checkForUpdateAsync();
        if (isAvailable) {
          try {
            setIsUpdating(true);
            const { isNew } = await Updates.fetchUpdateAsync();
            if (isNew) {
              await Updates.reloadAsync();
            }
          } catch (error) {
            console.log('Error while updating app:', error);
          } finally {
            setIsUpdating(false);
          }
        }
      })();
    }
  }, []);

  const setTokenAsync = async (userToken) => {
    await AsyncStorage.setItem('user-token', userToken); // Change to your user token storage key
    client.clearStore();
    setToken(userToken);
  };

  const logout = async () => {
    try {
      await AsyncStorage.removeItem('user-token'); // Change to your user token storage key
      setToken(null);
      // Add logic to stop location updates if applicable
    } catch (e) {
      console.log('Logout Error: ', e);
    }
  };

  if (isUpdating) {
    return (
      <View style={[
        styles.flex,
        styles.mainContainer,
        { backgroundColor: colors.startColor }
      ]}>
        <TextDefault textColor={colors.white} bold>
          Please wait while the app is updating
        </TextDefault>
        <ActivityIndicator size="large" color={colors.white} />
      </View>
    );
  }

  if (appIsReady) {
    return (
      <ApolloProvider client={client}>
        <StatusBar
          backgroundColor={colors.headerBackground}
          barStyle="dark-content"
        />
        <ConfigurationProvider>
          <AuthContext.Provider value={{ token, setTokenAsync, logout }}>
            <LocationProvider>
              <TabsContext.Provider value={{ active, setActive }}>
                <AppContainer />
              </TabsContext.Provider>
            </LocationProvider>
          </AuthContext.Provider>
        </ConfigurationProvider>
        <FlashMessage />
      </ApolloProvider>
    );
  }
  
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator size="large" color={colors.spinnerColor} />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: {
    flex: 1
  },
  mainContainer: {
    justifyContent: 'center',
    alignItems: 'center'
  }
});
